package com.razibul.NetPulse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fired by the system when a network becomes available: wake the meter up if it is not running. */
public class NetReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i != null && Keeper.ACTION_BEAT.equals(i.getAction())) {
            Keeper.start(c, Keeper.ACTION_BEAT);   // wake / check the meter
            Keeper.beat(c);                        // book the next beat in one minute
        } else {
            Keeper.start(c);
        }
    }
}
