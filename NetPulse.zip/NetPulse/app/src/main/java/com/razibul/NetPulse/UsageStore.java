package com.razibul.NetPulse;

import android.app.AppOpsManager;
import android.app.usage.NetworkStats;
import android.app.usage.NetworkStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Process;
import android.util.SparseArray;

import java.util.Calendar;

/**
 * Daily / monthly / per-app data usage.
 * Reads Android's own network statistics (NetworkStatsManager): nothing is logged by this app,
 * so it costs no battery and survives the app being killed or the phone rebooting.
 */
final class UsageStore {
    private UsageStore() {}

    static final int DAYS = 30;

    static final class Snapshot {
        long todayMob, todayWifi, weekMob, weekWifi, monthMob, monthWifi;
        long cycleStart;
        final long[] dayMob = new long[DAYS];   // index DAYS-1 = today
        final long[] dayWifi = new long[DAYS];
        final SparseArray<long[]> today = new SparseArray<>();  // uid -> {mobile, wifi}
        final SparseArray<long[]> week = new SparseArray<>();
        final SparseArray<long[]> month = new SparseArray<>();
        final SparseArray<String> names = new SparseArray<>();
        final SparseArray<Drawable> icons = new SparseArray<>();
    }

    // ------------------------------------------------------------ permission

    static boolean hasAccess(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode;
            if (Build.VERSION.SDK_INT >= 29) {
                mode = a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        Process.myUid(), c.getPackageName());
            } else {
                mode = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        Process.myUid(), c.getPackageName());
            }
            if (mode == AppOpsManager.MODE_DEFAULT) {
                return c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS")
                        == PackageManager.PERMISSION_GRANTED;
            }
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------ time helpers

    private static void zero(Calendar c) {
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }

    static long dayStart(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        zero(c);
        return c.getTimeInMillis();
    }

    /** Start of the current billing cycle (billing day is 1..28). */
    static long cycleStart(int day, long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        zero(c);
        if (c.get(Calendar.DAY_OF_MONTH) < day) c.add(Calendar.MONTH, -1);
        c.set(Calendar.DAY_OF_MONTH, Math.max(1, Math.min(day, 28)));
        return c.getTimeInMillis();
    }

    // ------------------------------------------------------------ light query (used by the service)

    /** {todayMobile, todayWifi, cycleMobile, cycleWifi} in bytes. Four tiny queries, very cheap. */
    static long[] totals(Context c, int billingDay) {
        NetworkStatsManager ns = (NetworkStatsManager) c.getSystemService(Context.NETWORK_STATS_SERVICE);
        long now = System.currentTimeMillis();
        long t0 = dayStart(now);
        long c0 = cycleStart(billingDay, now);
        return new long[]{
                dev(ns, ConnectivityManager.TYPE_MOBILE, t0, now),
                dev(ns, ConnectivityManager.TYPE_WIFI, t0, now),
                dev(ns, ConnectivityManager.TYPE_MOBILE, c0, now),
                dev(ns, ConnectivityManager.TYPE_WIFI, c0, now)};
    }

    private static long dev(NetworkStatsManager ns, int type, long from, long to) {
        try {
            NetworkStats.Bucket b = ns.querySummaryForDevice(type, null, from, to);
            return b.getRxBytes() + b.getTxBytes();
        } catch (Exception e) {
            return 0L;
        }
    }

    // ------------------------------------------------------------ full query (used by the Usage screen)

    static Snapshot load(Context c, int billingDay) {
        Snapshot s = new Snapshot();
        NetworkStatsManager ns = (NetworkStatsManager) c.getSystemService(Context.NETWORK_STATS_SERVICE);
        long now = System.currentTimeMillis();

        long[] ds = new long[DAYS + 1];               // day boundaries, ds[DAYS] = tomorrow 00:00
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        zero(cal);
        cal.add(Calendar.DAY_OF_YEAR, 1);
        ds[DAYS] = cal.getTimeInMillis();
        for (int i = DAYS - 1; i >= 0; i--) {
            cal.add(Calendar.DAY_OF_YEAR, -1);
            ds[i] = cal.getTimeInMillis();
        }
        long todayStart = ds[DAYS - 1];
        long weekStart = ds[DAYS - 7];
        s.cycleStart = cycleStart(billingDay, now);
        long from = Math.min(ds[0], s.cycleStart);

        int[] types = {ConnectivityManager.TYPE_MOBILE, ConnectivityManager.TYPE_WIFI};
        for (int type : types) {
            boolean mob = type == ConnectivityManager.TYPE_MOBILE;
            NetworkStats st = null;
            try {
                st = ns.querySummary(type, null, from, now + 3600000L);
                NetworkStats.Bucket b = new NetworkStats.Bucket();
                while (st.hasNextBucket()) {
                    st.getNextBucket(b);
                    long bytes = b.getRxBytes() + b.getTxBytes();
                    if (bytes <= 0L) continue;
                    long t = b.getStartTimeStamp();
                    int uid = b.getUid();
                    if (t >= ds[0]) {
                        int i = DAYS - 1;
                        while (i > 0 && ds[i] > t) i--;
                        if (mob) s.dayMob[i] += bytes; else s.dayWifi[i] += bytes;
                    }
                    if (t >= todayStart) {
                        add(s.today, uid, mob, bytes);
                        if (mob) s.todayMob += bytes; else s.todayWifi += bytes;
                    }
                    if (t >= weekStart) {
                        add(s.week, uid, mob, bytes);
                        if (mob) s.weekMob += bytes; else s.weekWifi += bytes;
                    }
                    if (t >= s.cycleStart) {
                        add(s.month, uid, mob, bytes);
                        if (mob) s.monthMob += bytes; else s.monthWifi += bytes;
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (st != null) st.close();
            }
        }

        resolve(c, s, s.today);
        resolve(c, s, s.week);
        resolve(c, s, s.month);
        return s;
    }

    private static void add(SparseArray<long[]> m, int uid, boolean mob, long bytes) {
        long[] v = m.get(uid);
        if (v == null) {
            v = new long[2];
            m.put(uid, v);
        }
        v[mob ? 0 : 1] += bytes;
    }

    private static void resolve(Context c, Snapshot s, SparseArray<long[]> m) {
        PackageManager pm = c.getPackageManager();
        for (int i = 0; i < m.size(); i++) {
            int uid = m.keyAt(i);
            if (s.names.indexOfKey(uid) >= 0) continue;
            String name;
            Drawable icon = null;
            if (uid == NetworkStats.Bucket.UID_REMOVED) {
                name = "Removed apps";
            } else if (uid == NetworkStats.Bucket.UID_TETHERING) {
                name = "Hotspot / tethering";
            } else if (uid == 0) {
                name = "Android system (root)";
            } else if (uid == 1000) {
                name = "Android system";
            } else {
                String[] p = pm.getPackagesForUid(uid);
                if (p == null || p.length == 0) {
                    name = "UID " + uid;
                } else {
                    try {
                        ApplicationInfo ai = pm.getApplicationInfo(p[0], 0);
                        name = String.valueOf(pm.getApplicationLabel(ai));
                        icon = pm.getApplicationIcon(ai);
                    } catch (Exception e) {
                        name = p[0];
                    }
                }
            }
            s.names.put(uid, name);
            if (icon != null) s.icons.put(uid, icon);
        }
    }
}
