package com.razibul.NetPulse;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.SystemClock;

/**
 * Keeps the meter alive without any polling of its own:
 *  1. the system wakes NetReceiver whenever a network appears (works even if the process was killed)
 *  2. a persisted 15-minute JobScheduler job (batched by the system, nearly free) restarts the service
 *  3. boot / app-update receivers restart it too
 * When there is no network nothing runs at all - the system holds the callbacks, not this app.
 */
final class Keeper {
    private Keeper() {}

    private static final int JOB_ID = 101;

    static void ensure(Context c) {
        if (!Prefs.enabled(c)) return;
        start(c);
        arm(c);
    }

    static final String ACTION_BEAT = "com.razibul.NetPulse.BEAT";
    private static final long BEAT_MS = 60 * 1000L;

    static void start(Context c) {
        start(c, null);
    }

    static void start(Context c, String action) {
        if (!Prefs.enabled(c)) return;
        try {
            Intent i = new Intent(c, SpeedService.class);
            if (action != null) i.setAction(action);
            c.startForegroundService(i);
        } catch (Exception ignored) {
            // background-start restrictions: the job / next network event will retry
        }
    }

    /**
     * Heartbeat: every minute the system wakes NetReceiver, which makes sure the meter is running and the
     * notification is on screen, then books the next beat. One tiny inexact alarm, no wake lock.
     */
    static void beat(Context c) {
        if (!Prefs.enabled(c)) return;
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + BEAT_MS, beatPi(c));
        } catch (Exception ignored) { }
    }

    static PendingIntent beatPi(Context c) {
        return PendingIntent.getBroadcast(c, 9,
                new Intent(c, NetReceiver.class).setAction(ACTION_BEAT),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void arm(Context c) {
        beat(c);
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null && js.getPendingJob(JOB_ID) == null) {
                js.schedule(new JobInfo.Builder(JOB_ID, new ComponentName(c, Watchdog.class))
                        .setPeriodic(15 * 60 * 1000L)
                        .setPersisted(true)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                        .build());
            }
        } catch (Exception ignored) { }
        try {
            ConnectivityManager cm = c.getSystemService(ConnectivityManager.class);
            NetworkRequest req = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            cm.registerNetworkCallback(req, netPi(c));
        } catch (Exception ignored) { }
    }

    /**
     * Swipe-from-recents / OEM-kill safety net: ask the system to start the meter again shortly.
     * One tiny one-shot alarm (no wakelock, no polling). Allowed to start the service because the
     * app is battery-unrestricted.
     */
    static void scheduleRestart(Context c, long delayMs) {
        if (!Prefs.enabled(c)) return;
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + delayMs, restartPi(c));
        } catch (Exception ignored) { }
    }

    static void disarm(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                am.cancel(restartPi(c));
                am.cancel(beatPi(c));
            }
        } catch (Exception ignored) { }
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null) js.cancel(JOB_ID);
        } catch (Exception ignored) { }
        try {
            c.getSystemService(ConnectivityManager.class).unregisterNetworkCallback(netPi(c));
        } catch (Exception ignored) { }
    }

    private static PendingIntent restartPi(Context c) {
        return PendingIntent.getBroadcast(c, 6, new Intent(c, NetReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent kickPi(Context c) {
        return PendingIntent.getBroadcast(c, 7, new Intent(c, NetReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent netPi(Context c) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getBroadcast(c, 5, new Intent(c, NetReceiver.class), flags);
    }
}
