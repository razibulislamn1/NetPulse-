package com.razibul.NetPulse;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Periodic safety net (needs a network, so it never runs while offline). */
public class Watchdog extends JobService {
    @Override
    public boolean onStartJob(JobParameters p) {
        Keeper.start(this);
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters p) {
        return true;
    }
}
