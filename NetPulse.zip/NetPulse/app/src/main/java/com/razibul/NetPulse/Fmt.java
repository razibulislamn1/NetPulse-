package com.razibul.NetPulse;

import java.util.Locale;

final class Fmt {
    private Fmt() {}

    /** Returns {number, unit}. bps is bytes per second. */
    static String[] speed(float bps, boolean bits) {
        if (bits) {
            float b = bps * 8f;
            if (b < 1000f) return new String[]{String.valueOf((int) b), "bps"};
            if (b < 1000000f) return new String[]{String.valueOf((int) (b / 1000f)), "Kbps"};
            if (b < 1000000000f) return new String[]{dec(b / 1000000f), "Mbps"};
            return new String[]{dec(b / 1000000000f), "Gbps"};
        }
        if (bps < 1024f) return new String[]{String.valueOf((int) bps), "B/s"};
        if (bps < 1048576f) return new String[]{String.valueOf((int) (bps / 1024f)), "KB/s"};
        if (bps < 1073741824f) return new String[]{dec(bps / 1048576f), "MB/s"};
        return new String[]{dec(bps / 1073741824f), "GB/s"};
    }

    /** Short form like 512B, 834K, 2.4M (used on the two-line status icon). */
    static String compact(float bps, boolean bits) {
        float v = bits ? bps * 8f : bps;
        float k = bits ? 1000f : 1024f;
        if (v < 1000f) return ((int) v) + (bits ? "b" : "B");
        float kv = v / k;
        if (kv < 1000f) return ((int) kv) + "K";
        float mv = kv / k;
        if (mv < 1000f) return dec(mv) + "M";
        return dec(mv / k) + "G";
    }

    /** Data amounts, decimal units like carriers use: 834 KB, 12.4 MB, 3.21 GB. */
    static String bytes(long b) {
        if (b < 1000L) return b + " B";
        double v = b / 1000.0;
        if (v < 1000.0) return String.format(Locale.US, v < 100 ? "%.1f KB" : "%.0f KB", v);
        v /= 1000.0;
        if (v < 1000.0) return String.format(Locale.US, v < 100 ? "%.1f MB" : "%.0f MB", v);
        v /= 1000.0;
        if (v < 1000.0) return String.format(Locale.US, "%.2f GB", v);
        return String.format(Locale.US, "%.2f TB", v / 1000.0);
    }

    /** 5 -> "5", 2.5 -> "2.5" */
    static String gb(float g) {
        return g == (int) g ? String.valueOf((int) g) : String.format(Locale.US, "%.1f", g);
    }

    private static String dec(float v) {
        return v < 10f ? String.format(Locale.US, "%.1f", v) : String.valueOf((int) v);
    }
}
