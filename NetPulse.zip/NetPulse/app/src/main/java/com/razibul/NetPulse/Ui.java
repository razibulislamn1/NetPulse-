package com.razibul.NetPulse;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.function.IntConsumer;

/**
 * Design system for NetPulse: aurora background, glass cards, animated controls.
 * Pure code, no layouts, no libraries.
 */
final class Ui {
    private Ui() {}

    static final int BG = 0xFF05060F, ACCENT = 0xFF7C5CFF, ACCENT2 = 0xFF00E5FF, ACCENT3 = 0xFF5B8CFF,
            PINK = 0xFFFF2E93, VIOLET = 0xFFB388FF,
            WHITE = 0xFFFFFFFF, MUTED = 0xFF8D96BD, DIM = 0xFF5F6893,
            GOOD = 0xFF3DFF8A, WARN = 0xFFFFB84D, BAD = 0xFFFF6B6B,
            GLASS_TOP = 0x1FFFFFFF, GLASS_BOT = 0x0A9AA8FF, EDGE = 0x2CFFFFFF, TRACK = 0x1AFFFFFF;

    // ------------------------------------------------------------------ basics

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static float sp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, c.getResources().getDisplayMetrics());
    }

    static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = Math.round(((a >>> 24) & 255) * (1f - t) + ((b >>> 24) & 255) * t);
        int rr = Math.round(((a >>> 16) & 255) * (1f - t) + ((b >>> 16) & 255) * t);
        int gg = Math.round(((a >>> 8) & 255) * (1f - t) + ((b >>> 8) & 255) * t);
        int bb = Math.round((a & 255) * (1f - t) + (b & 255) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static GradientDrawable rounded(Context c, int color, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(c, 1)), stroke);
        return g;
    }

    /** Frosted-glass surface: translucent gradient fill + hairline edge. */
    static GradientDrawable glass(Context c, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{GLASS_TOP, GLASS_BOT});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1)), EDGE);
        return g;
    }

    static GradientDrawable gradPill(Context c, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{ACCENT, ACCENT3});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(glass(c, 26));
        l.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        return l;
    }

    static TextView tv(Context c, String s, int sizeSp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0f, 1.15f);
        return t;
    }

    static TextView light(TextView t) {
        t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        return t;
    }

    static TextView section(Context c, String s) {
        TextView t = tv(c, s, 11, MUTED, true);
        t.setLetterSpacing(0.2f);
        return t;
    }

    static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x14FFFFFF);
        return v;
    }

    static LinearLayout.LayoutParams dividerLp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 1)));
        p.topMargin = dp(c, topDp);
        return p;
    }

    /** Gradient-painted text (title). */
    static void gradientText(final TextView t, final int... colors) {
        t.post(new Runnable() {
            @Override public void run() {
                float w = t.getPaint().measureText(t.getText().toString());
                t.getPaint().setShader(new LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.CLAMP));
                t.invalidate();
            }
        });
    }

    static CharSequence dotted(int color, String text) {
        SpannableStringBuilder b = new SpannableStringBuilder("\u25CF ");
        b.setSpan(new ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        b.append(text);
        return b;
    }

    static CharSequence lines(CharSequence a, CharSequence b) {
        return TextUtils.concat(a, "\n", b);
    }

    // ------------------------------------------------------------------ motion

    /** Soft press feedback (scale down, springy release). Click still works. */
    static void press(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View x, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    x.animate().setStartDelay(0L).scaleX(0.96f).scaleY(0.96f).setDuration(110L)
                            .setInterpolator(new DecelerateInterpolator()).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    x.animate().setStartDelay(0L).scaleX(1f).scaleY(1f).setDuration(260L)
                            .setInterpolator(new OvershootInterpolator(2.2f)).start();
                }
                return false;
            }
        });
    }

    static void reveal(final View v, long delayMs) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 20));
        v.animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(480L)
                .setInterpolator(new DecelerateInterpolator(1.8f))
                .withEndAction(new Runnable() {
                    @Override public void run() { v.animate().setStartDelay(0L); }
                }).start();
    }

    static void revealChildren(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) {
            reveal(g.getChildAt(i), 40L + Math.min(i, 12) * 55L);
        }
    }

    /** Rolls a data amount smoothly from its previous value to the new one. */
    static void countBytes(final TextView t, final long to) {
        Object tag = t.getTag();
        final long from = tag instanceof Long ? (Long) tag : 0L;
        t.setTag(to);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(750L);
        a.setInterpolator(new DecelerateInterpolator(2f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) {
                float f = (float) an.getAnimatedValue();
                t.setText(Fmt.bytes((long) (from + (to - from) * (double) f)));
            }
        });
        a.start();
    }

    // ------------------------------------------------------------------ window

    /** Transparent system bars + content drawn behind them; padTarget gets the insets as padding. */
    static void edgeToEdge(Activity a, View frame, final View padTarget, final int topDp, final int bottomDp,
                           final int sideDp) {
        Window w = a.getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            frame.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        final Context c = a;
        // never let the content start under the status bar, even if the system does not deliver insets
        int rid = a.getResources().getIdentifier("status_bar_height", "dimen", "android");
        final int sbh = rid > 0 ? a.getResources().getDimensionPixelSize(rid) : 0;
        padTarget.setPadding(dp(c, sideDp), dp(c, topDp) + sbh, dp(c, sideDp), dp(c, bottomDp));
        frame.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets in) {
                padTarget.setPadding(dp(c, sideDp) + in.getSystemWindowInsetLeft(),
                        dp(c, topDp) + Math.max(sbh, in.getSystemWindowInsetTop()),
                        dp(c, sideDp) + in.getSystemWindowInsetRight(),
                        dp(c, bottomDp) + in.getSystemWindowInsetBottom());
                return in;
            }
        });
    }

    // ------------------------------------------------------------------ buttons / inputs

    static TextView button(Context c, String s) {
        TextView b = tv(c, s, 13, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), gradPill(c, 16), null));
        press(b);
        return b;
    }

    static View segmented(Context c, String[] labels, int sel, IntConsumer cb) {
        return new Seg(c, labels, sel, cb);
    }

    static SeekBar seek(Context c, int max, int val, final IntConsumer onChange, final Runnable onStop) {
        SeekBar s = new SeekBar(c);
        s.setMax(max);
        s.setProgress(val);
        s.setProgressTintList(ColorStateList.valueOf(ACCENT));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(0x33FFFFFF));
        s.setThumbTintList(ColorStateList.valueOf(WHITE));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) {
                if (user) onChange.accept(p);
            }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { if (onStop != null) onStop.run(); }
        });
        return s;
    }

    // ================================================================== custom views

    /** Segmented control with a gradient pill that glides to the selected item. */
    static final class Seg extends FrameLayout {
        private final TextView[] t;
        private final IntConsumer cb;
        private final int pad;
        private final float radius;
        private final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private int sel;
        private float px, iw;
        private ValueAnimator anim;

        Seg(Context c, String[] labels, int sel, IntConsumer cb) {
            super(c);
            this.sel = sel;
            this.cb = cb;
            pad = dp(c, 4);
            radius = dp(c, 14);
            setBackground(glass(c, 18));
            setPadding(pad, pad, pad, pad);
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 42)));
            t = new TextView[labels.length];
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView x = new TextView(c);
                x.setText(labels[i]);
                x.setGravity(Gravity.CENTER);
                x.setTextSize(13);
                x.setSingleLine(true);
                x.setEllipsize(TextUtils.TruncateAt.END);
                x.setIncludeFontPadding(false);
                x.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { choose(idx); }
                });
                row.addView(x, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
                t[i] = x;
            }
            paint();
        }

        private void paint() {
            for (int i = 0; i < t.length; i++) {
                boolean on = i == sel;
                t[i].setTextColor(on ? WHITE : MUTED);
                t[i].setTypeface(Typeface.create(on ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
            }
        }

        private void choose(int i) {
            if (i == sel) return;
            sel = i;
            paint();
            float target = pad + i * iw;
            if (anim != null) anim.cancel();
            if (iw <= 0f) {
                px = target;
                invalidate();
            } else {
                anim = ValueAnimator.ofFloat(px, target);
                anim.setDuration(280L);
                anim.setInterpolator(new PathInterpolator(0.2f, 0f, 0f, 1f));
                anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(ValueAnimator a) {
                        px = (float) a.getAnimatedValue();
                        invalidate();
                    }
                });
                anim.start();
            }
            cb.accept(i);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            iw = (w - 2f * pad) / t.length;
            pp.setShader(new LinearGradient(0f, 0f, iw, 0f, ACCENT, ACCENT3, Shader.TileMode.CLAMP));
            px = pad + sel * iw;
        }

        @Override
        protected void dispatchDraw(Canvas cv) {
            if (iw > 0f) {
                cv.save();
                cv.translate(px, pad);
                rf.set(0f, 0f, iw, getHeight() - 2f * pad);
                cv.drawRoundRect(rf, radius, radius, pp);
                cv.restore();
            }
            super.dispatchDraw(cv);
        }
    }

    /** Animated on/off switch. */
    static final class Toggle extends View {
        interface Listener { void onChanged(boolean on); }

        private boolean on;
        private float t;
        private final Listener l;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private ValueAnimator anim;

        Toggle(Context c, boolean on, Listener l) {
            super(c);
            this.on = on;
            this.t = on ? 1f : 0f;
            this.l = l;
            setClickable(true);
            setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { set(!Toggle.this.on, true); }
            });
            press(this);
        }

        void set(boolean v, boolean notify) {
            if (v == on) return;
            on = v;
            if (anim != null) anim.cancel();
            anim = ValueAnimator.ofFloat(t, on ? 1f : 0f);
            anim.setDuration(260L);
            anim.setInterpolator(new PathInterpolator(0.2f, 0f, 0f, 1f));
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    t = (float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
            if (notify && l != null) l.onChanged(on);
        }

        @Override
        protected void onMeasure(int wms, int hms) {
            setMeasuredDimension(dp(getContext(), 58), dp(getContext(), 34));
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), r = h / 2f;
            rf.set(0f, 0f, w, h);
            p.setShader(null);
            p.setColor(0x33FFFFFF);
            cv.drawRoundRect(rf, r, r, p);
            if (t > 0.01f) {
                p.setShader(new LinearGradient(0f, 0f, w, 0f, ACCENT, ACCENT2, Shader.TileMode.CLAMP));
                p.setAlpha(Math.round(255f * t));
                cv.drawRoundRect(rf, r, r, p);
                p.setShader(null);
            }
            float pd = dp(getContext(), 4), tr = r - pd;
            float cx = pd + tr + (w - 2f * (pd + tr)) * t;
            p.setColor(0x33000000);
            cv.drawCircle(cx, r + dp(getContext(), 1), tr, p);
            p.setColor(WHITE);
            cv.drawCircle(cx, r, tr, p);
        }
    }

    /** Rounded progress bar with a gradient fill that animates to its value. */
    static final class Bar extends View {
        private float frac, shown;
        private int c1 = ACCENT, c2 = ACCENT2;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private ValueAnimator anim;

        Bar(Context c) {
            super(c);
        }

        void set(float f, int a, int b, boolean animate) {
            f = Math.max(0f, Math.min(1f, f));
            c1 = a;
            c2 = b;
            frac = f;
            if (anim != null) anim.cancel();
            if (!animate) {
                shown = f;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(shown, f);
            anim.setDuration(700L);
            anim.setInterpolator(new DecelerateInterpolator(2f));
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator an) {
                    shown = (float) an.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), r = h / 2f;
            rf.set(0f, 0f, w, h);
            p.setShader(null);
            p.setColor(TRACK);
            cv.drawRoundRect(rf, r, r, p);
            if (shown <= 0.002f) return;
            float fw = Math.max(h, w * shown);
            p.setShader(new LinearGradient(0f, 0f, fw, 0f, c1, c2, Shader.TileMode.CLAMP));
            rf.set(0f, 0f, fw, h);
            cv.drawRoundRect(rf, r, r, p);
            p.setShader(null);
        }
    }

    /** Slowly drifting aurora behind everything. */
    static final class Aurora extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private RadialGradient g1, g2, g3;
        private float r, phase;
        private ValueAnimator anim;

        Aurora(Context c) {
            super(c);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            r = Math.max(w, h) * 0.62f;
            g1 = new RadialGradient(0f, 0f, r, new int[]{0x667C5CFF, 0x00000000}, null, Shader.TileMode.CLAMP);
            g2 = new RadialGradient(0f, 0f, r * 0.9f, new int[]{0x3800E5FF, 0x00000000}, null, Shader.TileMode.CLAMP);
            g3 = new RadialGradient(0f, 0f, r * 0.8f, new int[]{0x30FF2E93, 0x00000000}, null, Shader.TileMode.CLAMP);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(30000L);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    phase = (float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) anim.cancel();
            super.onDetachedFromWindow();
        }

        @Override
        protected void onWindowVisibilityChanged(int v) {
            super.onWindowVisibilityChanged(v);
            if (anim == null) return;
            if (v == VISIBLE) { if (anim.isPaused()) anim.resume(); } else if (anim.isRunning()) anim.pause();
        }

        @Override
        protected void onDraw(Canvas cv) {
            cv.drawColor(BG);
            if (g1 == null) return;
            float w = getWidth(), h = getHeight();
            double t = phase * 2.0 * Math.PI;
            blob(cv, g1, w * (0.15f + 0.12f * (float) Math.sin(t)), h * (0.08f + 0.06f * (float) Math.cos(t)));
            blob(cv, g2, w * (0.92f + 0.08f * (float) Math.cos(t + 1.0)), h * (0.48f + 0.08f * (float) Math.sin(t + 2.0)));
            blob(cv, g3, w * (0.25f + 0.10f * (float) Math.sin(t + 3.0)), h * (0.95f + 0.04f * (float) Math.cos(t)));
        }

        private void blob(Canvas cv, RadialGradient g, float x, float y) {
            p.setShader(g);
            cv.save();
            cv.translate(x, y);
            cv.drawCircle(0f, 0f, r, p);
            cv.restore();
        }
    }

    /** Live 45-second traffic graph: smooth curves that glide to the left. */
    static final class Spark extends View {
        static final int N = 45;
        private final float[] d = new float[N], u = new float[N];
        private float scale = 20480f, tScale = 20480f;
        private long pushT;
        private int colD = ACCENT2, fillColor;
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path(), area = new Path();
        private float top, bot;

        Spark(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
            fill.setStyle(Paint.Style.FILL);
            grid.setColor(0x12FFFFFF);
            grid.setStrokeWidth(Math.max(1f, dp(c, 1)));
        }

        void push(float down, float up, int colorDown) {
            System.arraycopy(d, 1, d, 0, N - 1);
            System.arraycopy(u, 1, u, 0, N - 1);
            d[N - 1] = down;
            u[N - 1] = up;
            colD = colorDown;
            pushT = AnimationUtils.currentAnimationTimeMillis();
            float mx = 20480f;
            for (int i = 0; i < N; i++) mx = Math.max(mx, Math.max(d[i], u[i]));
            tScale = mx * 1.15f;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            top = dp(getContext(), 6);
            bot = h - dp(getContext(), 6);
            fillColor = 0;
        }

        private float y(float v) {
            return bot - (bot - top) * Math.min(1f, v / scale);
        }

        private void build(Path p, float[] v, float phase, float dx) {
            p.reset();
            float px = 0f, py = y(v[0]);
            p.moveTo(px, py);
            for (int i = 0; i < N; i++) {
                float x = (i + phase) * dx, yy = y(v[i]);
                float cx = (px + x) / 2f;
                p.cubicTo(cx, py, cx, yy, x, yy);
                px = x;
                py = yy;
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth();
            if (w <= 0f) return;
            long now = AnimationUtils.currentAnimationTimeMillis();
            float phase = 1f - Math.max(0f, Math.min(1f, (now - pushT) / 1000f));
            scale += (tScale - scale) * 0.08f;
            float dx = w / (N - 1);

            for (int k = 0; k < 3; k++) {
                float yy = top + (bot - top) * k / 2f;
                cv.drawLine(0f, yy, w, yy, grid);
            }

            build(path, u, phase, dx);
            line.setShader(null);
            line.setStrokeWidth(dp(getContext(), 1) * 1.6f);
            line.setColor(alpha(VIOLET, 0xB0));
            cv.drawPath(path, line);

            build(path, d, phase, dx);
            if (fillColor != colD) {
                fillColor = colD;
                fill.setShader(new LinearGradient(0f, top, 0f, bot, alpha(colD, 0x55), alpha(colD, 0x00),
                        Shader.TileMode.CLAMP));
            }
            area.set(path);
            area.lineTo((N - 1 + phase) * dx, bot);
            area.lineTo(0f, bot);
            area.close();
            cv.drawPath(area, fill);
            line.setStrokeWidth(dp(getContext(), 1) * 2.4f);
            line.setColor(colD);
            cv.drawPath(path, line);

            if (phase > 0f || Math.abs(tScale - scale) > 1f) postInvalidateOnAnimation();
        }
    }

    /** Circular speedometer: log-scaled arc, lit ticks, glow, rolling number. */
    static final class Gauge extends View {
        private float target, shown;
        private long lastT;
        private boolean bits;
        private int color = ACCENT2, shaderColor;
        private String label = "DOWNLOAD";
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint unit = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();
        private SweepGradient sg;

        Gauge(Context c) {
            super(c);
            float sw = dp(c, 14);
            for (Paint p : new Paint[]{track, arc, glow}) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(sw);
            }
            track.setColor(0x14FFFFFF);
            tick.setStrokeCap(Paint.Cap.ROUND);
            tick.setStrokeWidth(dp(c, 2));
            big.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            big.setTextSize(sp(c, 58));
            big.setColor(WHITE);
            big.setTextAlign(Paint.Align.CENTER);
            unit.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            unit.setTextSize(sp(c, 16));
            unit.setTextAlign(Paint.Align.CENTER);
            lab.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            lab.setTextSize(sp(c, 11));
            lab.setLetterSpacing(0.22f);
            lab.setColor(MUTED);
            lab.setTextAlign(Paint.Align.CENTER);
        }

        void setTarget(float bps, boolean bits, int color, String label) {
            this.target = bps;
            this.bits = bits;
            this.color = color;
            this.label = label;
            invalidate();
        }

        @Override
        protected void onMeasure(int wms, int hms) {
            int w = MeasureSpec.getSize(wms);
            int s = Math.min(w, dp(getContext(), 270));
            setMeasuredDimension(s, s);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            sg = null;
        }

        private boolean speedScale;
        private static final float[] MBPS_STEPS = {0f, 1f, 5f, 10f, 20f, 50f, 100f, 250f, 500f, 1000f};

        /** Speed-test scale: evenly spaced steps 0-1-5-10-20-50-100-250-500-1000 Mbps, so slow stays visibly slow. */
        void setSpeedScale(boolean on) {
            speedScale = on;
            invalidate();
        }

        private float fracOf(float bps) {
            if (speedScale) {
                float m = bps * 8f / 1000000f;
                int n = MBPS_STEPS.length - 1;
                if (m <= 0f) return 0f;
                if (m >= MBPS_STEPS[n]) return 1f;
                for (int i = 0; i < n; i++) {
                    if (m < MBPS_STEPS[i + 1]) {
                        return (i + (m - MBPS_STEPS[i]) / (MBPS_STEPS[i + 1] - MBPS_STEPS[i])) / n;
                    }
                }
                return 1f;
            }
            if (bps < 1f) return 0f;
            double f = Math.log10(1.0 + bps / 1024.0) / 4.3;
            return (float) Math.max(0.0, Math.min(1.0, f));
        }

        @Override
        protected void onDraw(Canvas cv) {
            long now = AnimationUtils.currentAnimationTimeMillis();
            float dt = lastT == 0L ? 16f : Math.min(100f, now - lastT);
            lastT = now;
            shown += (target - shown) * (1f - (float) Math.exp(-dt / 150f));
            boolean moving = Math.abs(target - shown) > Math.max(8f, Math.abs(target) * 0.002f);
            if (!moving) {
                shown = target;
                lastT = 0L;
            }

            float w = getWidth(), cx = w / 2f, cy = w / 2f;
            float sw = track.getStrokeWidth();
            float r = w / 2f - sw * 1.7f;
            oval.set(cx - r, cy - r, cx + r, cy + r);
            float frac = fracOf(shown);
            float sweep = 270f * frac;

            if (sg == null || shaderColor != color) {
                shaderColor = color;
                sg = new SweepGradient(cx, cy,
                        new int[]{0xFF4B2BFF, ACCENT, color, color},
                        new float[]{0f, 0.38f, 0.75f, 1f});
                arc.setShader(sg);
            }

            // ticks
            float ri = r - sw * 1.2f, rl = ri - sw * 0.5f;
            int nt = 37;
            for (int i = 0; i < nt; i++) {
                float f = i / (float) (nt - 1);
                double a = Math.toRadians(135.0 + 270.0 * f);
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                tick.setColor(f <= frac && frac > 0f ? alpha(color, 0xB8) : 0x1FFFFFFF);
                cv.drawLine(cx + ri * ca, cy + ri * sa, cx + rl * ca, cy + rl * sa, tick);
            }

            cv.drawArc(oval, 135f, 270f, false, track);
            if (sweep > 0.6f) {
                glow.setStrokeWidth(sw * 2.4f);
                glow.setColor(alpha(color, 0x1C));
                cv.drawArc(oval, 135f, sweep, false, glow);
                glow.setStrokeWidth(sw * 1.6f);
                glow.setColor(alpha(color, 0x30));
                cv.drawArc(oval, 135f, sweep, false, glow);
                cv.save();
                cv.rotate(135f, cx, cy);
                cv.drawArc(oval, 0f, sweep, false, arc);
                cv.restore();
                double a = Math.toRadians(135.0 + sweep);
                float tx = cx + r * (float) Math.cos(a), ty = cy + r * (float) Math.sin(a);
                dot.setColor(alpha(WHITE, 0x44));
                cv.drawCircle(tx, ty, sw * 0.95f, dot);
                dot.setColor(WHITE);
                cv.drawCircle(tx, ty, sw * 0.4f, dot);
            }

            String[] f = Fmt.speed(shown, bits);
            Paint.FontMetrics fm = big.getFontMetrics();
            cv.drawText(label, cx, cy - r * 0.52f, lab);
            cv.drawText(f[0], cx, cy - (fm.ascent + fm.descent) / 2f + r * 0.02f, big);
            unit.setColor(mix(color, WHITE, 0.35f));
            cv.drawText(f[1], cx, cy + r * 0.58f, unit);

            if (moving) postInvalidateOnAnimation();
        }
    }
}
