package com.razibul.NetPulse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Optional "force colour" mode.
 * Android draws every notification icon in one system colour, so a coloured speed text is impossible
 * inside the real status-bar icon. This overlay draws the speed as a tiny coloured text on top of the
 * status bar instead (needs the "Display over other apps" permission). It is OFF by default, it is only
 * touched when the text actually changes, and it is removed while the screen is off.
 */
final class Overlay {
    private final Context c;
    private final WindowManager wm;
    private TextView tv;
    private WindowManager.LayoutParams lp;
    private boolean added;

    Overlay(Context c) {
        this.c = c;
        this.wm = c.getSystemService(WindowManager.class);
    }

    static boolean allowed(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static boolean wanted(SharedPreferences p, Context c) {
        return p.getBoolean("overlay", false) && allowed(c);
    }

    private int statusBarHeight() {
        int id = c.getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? c.getResources().getDimensionPixelSize(id) : Ui.dp(c, 24);
    }

    void show(SharedPreferences p, float d, float u, int color) {
        try {
            boolean bits = p.getBoolean("bits", false);
            int show = p.getInt("show", Prefs.SHOW_BOTH);
            String text;
            if (show == Prefs.SHOW_BOTH) {
                text = "\u2193" + Fmt.compact(d, bits) + "\n\u2191" + Fmt.compact(u, bits);
            } else {
                float v = show == Prefs.SHOW_UP ? u : show == Prefs.SHOW_TOTAL ? d + u : d;
                String[] f = Fmt.speed(v, bits);
                text = f[0] + "\n" + f[1];
            }
            float scale = Math.max(60, Math.min(250, p.getInt("iconScale", 100))) / 100f;
            int x = (int) (c.getResources().getDisplayMetrics().widthPixels
                    * Math.max(0, Math.min(100, p.getInt("ovX", 40))) / 100f);

            if (tv == null) {
                tv = new TextView(c);
                tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                tv.setIncludeFontPadding(false);
                tv.setLineSpacing(0f, 0.9f);
                tv.setShadowLayer(3f, 0f, 0f, 0xCC000000);
                lp = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT, statusBarHeight(),
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.START;
                lp.y = 0;
            }
            tv.setTypeface(Typeface.create(IconArt.FONTS[Math.max(0,
                    Math.min(IconArt.FONTS.length - 1, p.getInt("font", 0)))],
                    p.getBoolean("bold", true) ? Typeface.BOLD : Typeface.NORMAL));
            // fixed size: depends only on the user's size setting, never on the value
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f * scale);
            tv.setTextColor(color);
            tv.setText(text);
            lp.x = x;
            if (added) {
                wm.updateViewLayout(tv, lp);
            } else {
                wm.addView(tv, lp);
                added = true;
            }
        } catch (Exception e) {
            added = false;
        }
    }

    void hide() {
        if (!added || tv == null) return;
        try { wm.removeView(tv); } catch (Exception ignored) { }
        added = false;
    }
}
