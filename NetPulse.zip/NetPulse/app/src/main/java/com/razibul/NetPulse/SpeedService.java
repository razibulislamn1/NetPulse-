package com.razibul.NetPulse;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.TrafficStats;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

/**
 * Lightweight always-on speed meter.
 * - Polls TrafficStats once per second ONLY while the screen is on and a network exists.
 * - Network changes are event driven (no polling). No wake locks.
 * - When the network goes away the indicator is hidden after 10 seconds and everything sleeps;
 *   the system wakes it again when a network returns (see Keeper).
 * - Data totals / plan alerts: 4 tiny system queries every 5 min, only while screen on + online.
 */
public class SpeedService extends Service {

    static final String ACTION_REFRESH = "com.razibul.NetPulse.REFRESH";

    private static final String CH_KEEP = "np_keep";
    private static final String CH_SPEED = "np_speed2";
    private static final int ID_KEEP = 1;
    private static final int ID_SPEED = 2;
    private static final long HIDE_DELAY_MS = 10000L;
    private static final long USAGE_EVERY_MS = 5 * 60 * 1000L;
    private static final String CH_ALERT = "np_alert";
    private static final int ID_ALERT = 3;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;
    private NotificationManager nm;
    private ConnectivityManager cm;
    private PendingIntent openApp;
    private Overlay overlay;
    private int idleTicks, presenceTick;

    // cached prefs
    private int show, refreshMs;
    private boolean bits, hideIdle, showUsage;

    // state
    private Network cur;
    private boolean connected, shown = true, screenOn = true, ticking;
    private long lastRx, lastTx, lastT;
    private float lastDown, lastUp;
    private String lastKey = "";
    private String usageText = "";
    private long lastUsageAt = -USAGE_EVERY_MS;
    private boolean usageBusy;



    @Override
    public void onCreate() {
        super.onCreate();
        sp = Prefs.sp(this);
        nm = getSystemService(NotificationManager.class);
        cm = getSystemService(ConnectivityManager.class);
        PowerManager pm = getSystemService(PowerManager.class);
        screenOn = pm.isInteractive();

        createChannels();
        openApp = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        overlay = new Overlay(this);
        loadPrefs();
        goForeground();
        cur = cm.getActiveNetwork();
        connected = cur != null;
        cm.registerDefaultNetworkCallback(netCb);

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenRx, f);

        Keeper.arm(this);
        if (!connected) h.postDelayed(hideRun, HIDE_DELAY_MS);
        startTicking();
        lastDown = 0f;
        lastUp = 0f;
        render();
    }

    /**
     * The speed notification IS the foreground notification (one notification, nothing else to swipe away).
     * Calling this again also brings it back if the user swiped it off.
     */
    private void goForeground() {
        Notification n = buildSpeed(lastDown, lastUp);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_SPEED, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(ID_SPEED, n);
        }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && Keeper.ACTION_BEAT.equals(i.getAction())) {
            // 1-minute heartbeat: only repair what is missing (cheap when everything is fine)
            if (!isShowing()) {
                goForeground();
                lastKey = "";
                render();
            }
            if (screenOn && !ticking) startTicking();
            return START_STICKY;
        }
        if (i == null || i.getAction() == null) {
            // (re)started by the system / watchdog / alarm / dismissed notification: put the speed back right away
            goForeground();
            loadPrefs();
            lastKey = "";
            render();
            startTicking();
        }
        if (i != null && ACTION_REFRESH.equals(i.getAction())) {
            loadPrefs();
            lastKey = "";
            render();
            if (i.getBooleanExtra("usage", true) && screenOn && connected) kickUsage(true);
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // swiped away from recents: the meter must keep running. The service stays up (stopWithTask=false);
        // re-arm every safety net and re-draw the speed immediately, so the top bar never goes blank.
        Keeper.arm(this);
        Keeper.scheduleRestart(this, 1500L);
        loadPrefs();
        lastKey = "";
        render();
        startTicking();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try { cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        try { unregisterReceiver(screenRx); } catch (Exception ignored) { }
        if (overlay != null) overlay.hide();
        // killed by the system / OEM cleaner while the meter is still switched on: come back by ourselves
        Keeper.scheduleRestart(this, 2000L);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- state

    private final ConnectivityManager.NetworkCallback netCb = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(final Network n) {
            h.post(new Runnable() {
                @Override public void run() {
                    cur = n;
                    setConnected(true);
                }
            });
        }

        @Override
        public void onLost(final Network n) {
            h.post(new Runnable() {
                @Override public void run() {
                    if (n.equals(cur)) {
                        cur = null;
                        setConnected(false);
                    }
                }
            });
        }
    };

    private final BroadcastReceiver screenRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                screenOn = false;
                h.removeCallbacks(tick);
                h.removeCallbacks(usageRun);
                ticking = false;
                overlay.hide();
            } else {
                screenOn = true;
            lastKey = "";
                startTicking();
            }
        }
    };

    private final Runnable hideRun = new Runnable() {
        @Override
        public void run() {
            // offline: the icon stays (it must always be there), only the ticking sleeps
            shown = false;
            lastDown = 0f;
            lastUp = 0f;
            lastKey = "";
            render();
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!screenOn || (!connected && !shown)) {
                ticking = false;
                return;
            }
            update();
            // swiped away anyway? put it back within a few seconds (one cheap check every 2nd tick)
            if ((++presenceTick & 1) == 0 && !isShowing()) goForeground();
            // battery: when nothing is moving for a while, check less often (instantly back to normal on traffic)
            long next = (long) refreshMs;
            if (idleTicks > 8) next = Math.max(next, 2000L);
            if (idleTicks > 30) next = Math.max(next, 3000L);
            h.postDelayed(this, next);
        }
    };

    private boolean isShowing() {
        try {
            for (android.service.notification.StatusBarNotification n : nm.getActiveNotifications()) {
                if (n.getId() == ID_SPEED) return true;
            }
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    private void setConnected(boolean c) {
        if (c == connected) return;
        connected = c;
        h.removeCallbacks(hideRun);
        if (c) {
            shown = true;
            lastKey = "";
            lastDown = 0f;
            lastUp = 0f;
            render();
            startTicking();
        } else {
            h.removeCallbacks(usageRun);
            h.postDelayed(hideRun, HIDE_DELAY_MS);
        }
    }

    private void startTicking() {
        if (ticking || !screenOn || (!connected && !shown)) return;
        ticking = true;
        lastRx = Math.max(0L, TrafficStats.getTotalRxBytes());
        lastTx = Math.max(0L, TrafficStats.getTotalTxBytes());
        lastT = SystemClock.elapsedRealtime();
        h.postDelayed(tick, 1000L);
        if (connected) kickUsage(false);
    }

    // ---------------------------------------------------------------- data usage / plan alerts

    private final Runnable usageRun = new Runnable() {
        @Override
        public void run() {
            if (!screenOn || !connected) return;   // asleep: no screen or no network
            refreshUsage();
            h.postDelayed(this, USAGE_EVERY_MS);
        }
    };

    private void kickUsage(boolean force) {
        h.removeCallbacks(usageRun);
        long wait = force ? 0L
                : Math.max(0L, USAGE_EVERY_MS - (SystemClock.elapsedRealtime() - lastUsageAt));
        h.postDelayed(usageRun, wait);
    }

    private void refreshUsage() {
        if (usageBusy || !UsageStore.hasAccess(this)) return;
        usageBusy = true;
        lastUsageAt = SystemClock.elapsedRealtime();
        final int day = sp.getInt("billDay", 1);
        new Thread(new Runnable() {
            @Override public void run() {
                final long[] t = UsageStore.totals(SpeedService.this, day);
                h.post(new Runnable() {
                    @Override public void run() {
                        usageBusy = false;
                        applyUsage(t);
                    }
                });
            }
        }, "np-usage").start();
    }

    private void applyUsage(long[] t) {
        usageText = "Today " + Fmt.bytes(t[0] + t[1]) + "  \u00B7  Month " + Fmt.bytes(t[2] + t[3]);
        lastKey = "";
        render();
        checkPlan(t[2]);
    }

    private void checkPlan(long mobileCycle) {
        float planGb = sp.getFloat("planGb", 0f);
        if (planGb <= 0f) return;
        double frac = mobileCycle / (planGb * 1e9);
        long cyc = UsageStore.cycleStart(sp.getInt("billDay", 1), System.currentTimeMillis());
        int level = sp.getLong("alertCycle", 0L) == cyc ? sp.getInt("alertLevel", 0) : 0;
        int now = frac >= 1.0 ? 100 : frac >= 0.8 ? 80 : 0;
        if (now > level) {
            String title = now == 100 ? "Data limit reached" : "80% of your data plan used";
            String text = Fmt.bytes(mobileCycle) + " of " + Fmt.gb(planGb) + " GB mobile data used this cycle";
            Notification n = new Notification.Builder(this, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(this, 1,
                            new Intent(this, UsageActivity.class), PendingIntent.FLAG_IMMUTABLE))
                    .build();
            nm.notify(ID_ALERT, n);
            sp.edit().putLong("alertCycle", cyc).putInt("alertLevel", now).apply();
        } else if (now < level || sp.getLong("alertCycle", 0L) != cyc) {
            sp.edit().putLong("alertCycle", cyc).putInt("alertLevel", now).apply();
        }
    }

    private void loadPrefs() {
        show = sp.getInt("show", Prefs.SHOW_BOTH);
        bits = sp.getBoolean("bits", false);
        hideIdle = sp.getBoolean("hideIdle", false);
        showUsage = sp.getBoolean("showUsage", true);
        refreshMs = 1000 * Math.max(1, Math.min(3, sp.getInt("refresh", 1)));
    }

    private void update() {
        long now = SystemClock.elapsedRealtime();
        long rx = Math.max(0L, TrafficStats.getTotalRxBytes());
        long tx = Math.max(0L, TrafficStats.getTotalTxBytes());
        long dt = Math.max(1L, now - lastT);
        float d = Math.max(0L, rx - lastRx) * 1000f / dt;
        float u = Math.max(0L, tx - lastTx) * 1000f / dt;
        lastRx = rx;
        lastTx = tx;
        lastT = now;
        if (!connected) {
            d = 0f;
            u = 0f;
        }
        lastDown = d;
        lastUp = u;
        if (d < 1024f && u < 1024f) { if (idleTicks < 1000) idleTicks++; } else idleTicks = 0;
        render();
    }

    // ---------------------------------------------------------------- drawing

    private void render() {
        float d = lastDown, u = lastUp;
        String[] fd = Fmt.speed(d, bits), fu = Fmt.speed(u, bits);
        boolean idle = false;  // the icon is never hidden
        int col = Prefs.color(sp, d);
        String key = Fmt.compact(d, bits) + "|" + Fmt.compact(u, bits) + "|" + fd[0] + fd[1] + "|" + fu[0] + fu[1]
                + "|" + Fmt.speed(d + u, bits)[0] + Fmt.speed(d + u, bits)[1] + "|" + idle + "|" + col
                + "|" + usageText + "|" + connected;
        if (key.equals(lastKey)) return;
        lastKey = key;
        postNotification(d, u, fd, fu, col);
    }

    /**
     * The status-bar icon is a real notification icon: the system itself places it in the notification
     * area of the top bar next to the other icons, so it can never overlap anything.
     */
    private void postNotification(float d, float u, String[] fd, String[] fu, int accent) {
        nm.notify(ID_SPEED, buildSpeed(d, u));
    }

    private Notification buildSpeed(float d, float u) {
        String[] fd = Fmt.speed(d, bits), fu = Fmt.speed(u, bits);
        int accent = Prefs.color(sp, d);
        boolean ov = Overlay.wanted(sp, this);
        Icon smallIcon;
        if (ov) {
            // coloured text is drawn by the overlay; the system icon stays a small static mark
            smallIcon = Icon.createWithResource(this, R.drawable.ic_stat);
            overlay.show(sp, d, u, accent);
        } else {
            overlay.hide();
            smallIcon = Icon.createWithBitmap(IconArt.draw(sp, d, u));
        }
        String title;
        if (show == Prefs.SHOW_DOWN) {
            title = "\u2193 " + fd[0] + " " + fd[1];
        } else if (show == Prefs.SHOW_UP) {
            title = "\u2191 " + fu[0] + " " + fu[1];
        } else if (show == Prefs.SHOW_TOTAL) {
            String[] ft = Fmt.speed(d + u, bits);
            title = "\u2195 " + ft[0] + " " + ft[1];
        } else {
            title = "\u2193 " + fd[0] + " " + fd[1] + "    \u2191 " + fu[0] + " " + fu[1];
        }
        String text = !connected ? "No network"
                : (showUsage && !usageText.isEmpty()) ? usageText : "Network active";
        Notification n = new Notification.Builder(this, CH_SPEED)
                .setSmallIcon(smallIcon)
                .setColor(accent)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openApp)
                .setDeleteIntent(PendingIntent.getForegroundService(this, 8,
                        new Intent(this, SpeedService.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setPriority(Notification.PRIORITY_DEFAULT)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build();
        n.flags |= Notification.FLAG_NO_CLEAR | Notification.FLAG_ONGOING_EVENT;
        return n;
    }

    private void createChannels() {
        NotificationChannel keep = new NotificationChannel(CH_KEEP, "Background service",
                NotificationManager.IMPORTANCE_MIN);
        keep.setShowBadge(false);
        // DEFAULT importance (silent) so the system always shows the icon in the status bar,
        // not only in the shade (LOW / MIN icons are hidden on many phones).
        NotificationChannel speed = new NotificationChannel(CH_SPEED, "Live speed (status bar)",
                NotificationManager.IMPORTANCE_DEFAULT);
        speed.setShowBadge(false);
        speed.enableVibration(false);
        speed.setSound(null, null);
        speed.enableLights(false);
        NotificationChannel alert = new NotificationChannel(CH_ALERT, "Data plan alerts",
                NotificationManager.IMPORTANCE_HIGH);
        alert.setShowBadge(false);
        nm.deleteNotificationChannel("np_speed");
        nm.createNotificationChannel(alert);
        nm.deleteNotificationChannel(CH_KEEP);
        nm.createNotificationChannel(speed);
    }
}
