package com.razibul.NetPulse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.SystemClock;

final class Prefs {
    private Prefs() {}

    static final int SHOW_DOWN = 0, SHOW_UP = 1, SHOW_BOTH = 2, SHOW_TOTAL = 3;
    static final int STYLE_DUAL = 0, STYLE_BIG = 1;
    static final int T_HEAT = 8, T_RAINBOW = 9, T_CUSTOM = 10;

    static final int[] COLORS = {
            0xFFB6FF3B, // neon lime
            0xFF00E5FF, // cyber cyan
            0xFFFF2E93, // hot pink
            0xFFFF8A3D, // sunset
            0xFFFFFFFF, // ice white
            0xFFFFD54A, // gold
            0xFF7CFFCB, // aurora
            0xFFB388FF  // violet
    };

    /** The meter is ON by default; the user can switch it off in the app. */
    static boolean enabled(Context c) {
        return sp(c).getBoolean("enabled", true);
    }

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("netpulse", Context.MODE_PRIVATE);
    }

    /** Text colour for the current theme. bps = bytes per second (used by the Heat theme). */
    static int color(SharedPreferences p, float bps) {
        int t = p.getInt("theme", 1);
        if (t >= 0 && t < COLORS.length) return COLORS[t];
        if (t == T_HEAT) {
            if (bps < 50f * 1024f) return 0xFF4DA3FF;
            if (bps < 1024f * 1024f) return 0xFF3DFF8A;
            if (bps < 5f * 1024f * 1024f) return 0xFFFFE03D;
            return 0xFFFF4D4D;
        }
        if (t == T_RAINBOW) {
            float hue = (float) ((SystemClock.uptimeMillis() / 20L) % 360L);
            return Color.HSVToColor(new float[]{hue, 0.75f, 1f});
        }
        return Color.HSVToColor(new float[]{p.getInt("hue", 200), 0.85f, 1f});
    }
}
