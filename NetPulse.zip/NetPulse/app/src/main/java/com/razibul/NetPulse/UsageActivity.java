package com.razibul.NetPulse;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

/** Daily / monthly data usage, per-app breakdown, 30-day chart and data-plan alerts. */
public class UsageActivity extends Activity {

    private static final int MOB = Ui.ACCENT, MOB2 = Ui.VIOLET, WIFI = Ui.ACCENT2;

    private SharedPreferences sp;
    private UsageStore.Snapshot snap;
    private int range = 0, filter = 0;
    private boolean loading;

    private LinearLayout permCard, list;
    private TextView todayBig, todaySub, monthBig, monthSub, monthLbl, planText, chartCap, listHead;
    private TextView lblPlan, lblDay;
    private Ui.Bar planBar;
    private Chart chart;
    private UsageStore.Snapshot bound;

    private static final class Row {
        int uid;
        long mob, wifi, v;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Prefs.sp(this);
        FrameLayout frame = new FrameLayout(this);
        frame.addView(new Ui.Aurora(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout root = build();
        sv.addView(root);
        frame.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Ui.edgeToEdge(this, frame, root, 18, 40, 18);
        setContentView(frame);
        Ui.revealChildren(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ok = UsageStore.hasAccess(this);
        permCard.setVisibility(ok ? View.GONE : View.VISIBLE);
        if (ok) reload(); else render();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    // ------------------------------------------------------------------ UI

    private LinearLayout build() {
        final Context c = this;
        LinearLayout root = Ui.col(this);
        root.setPadding(Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 18), Ui.dp(c, 40));

        // ---- header with back button
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = Ui.tv(c, "\u2039", 28, Ui.WHITE, false);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.glass(c, 23));
        back.setPadding(0, 0, 0, Ui.dp(c, 3));
        Ui.press(back);
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(c, 46), Ui.dp(c, 46)));
        LinearLayout ht = Ui.col(this);
        ht.setPadding(Ui.dp(c, 14), 0, 0, 0);
        TextView title = Ui.tv(c, "Data usage", 26, Ui.WHITE, true);
        Ui.gradientText(title, Ui.WHITE, 0xFFC9BDFF, Ui.ACCENT2);
        ht.addView(title);
        ht.addView(Ui.tv(c, "Android's own stats \u00B7 no logging \u00B7 zero battery cost", 11, Ui.MUTED, false),
                Ui.lp(c, 3));
        head.addView(ht, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(head);

        // ---- permission card
        permCard = Ui.card(this);
        permCard.addView(Ui.tv(c, "Usage access needed", 15, Ui.WHITE, true));
        permCard.addView(Ui.tv(c, "Allow NetPulse under \"Usage access\" to see daily, monthly and per-app data.",
                12, Ui.MUTED, false), Ui.lp(c, 4));
        TextView grant = Ui.button(c, "Grant usage access");
        grant.setOnClickListener(v -> openUsageAccess());
        permCard.addView(grant, Ui.lp(c, 14));
        root.addView(permCard, Ui.lp(c, 18));

        // ---- today / month
        LinearLayout two = new LinearLayout(this);
        two.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout a = Ui.card(this);
        a.addView(Ui.section(c, "TODAY"));
        todayBig = Ui.light(Ui.tv(c, "\u2014", 26, Ui.WHITE, false));
        todaySub = Ui.tv(c, "", 11, Ui.MUTED, false);
        a.addView(todayBig, Ui.lp(c, 10));
        a.addView(todaySub, Ui.lp(c, 8));
        LinearLayout m = Ui.card(this);
        monthLbl = Ui.section(c, "THIS MONTH");
        m.addView(monthLbl);
        monthBig = Ui.light(Ui.tv(c, "\u2014", 26, Ui.WHITE, false));
        monthSub = Ui.tv(c, "", 11, Ui.MUTED, false);
        m.addView(monthBig, Ui.lp(c, 10));
        m.addView(monthSub, Ui.lp(c, 8));
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        la.rightMargin = Ui.dp(c, 6);
        LinearLayout.LayoutParams lm = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lm.leftMargin = Ui.dp(c, 6);
        two.addView(a, la);
        two.addView(m, lm);
        root.addView(two, Ui.lp(c, 14));

        // ---- chart
        LinearLayout cc = Ui.card(this);
        cc.addView(Ui.section(c, "LAST 30 DAYS"));
        chart = new Chart(this);
        chart.cb = this::pickDay;
        cc.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 136)));
        ((LinearLayout.LayoutParams) chart.getLayoutParams()).topMargin = Ui.dp(c, 10);
        chartCap = Ui.tv(c, "", 12, Ui.MUTED, false);
        cc.addView(chartCap, Ui.lp(c, 10));
        LinearLayout legend = new LinearLayout(this);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        legend.addView(dot(MOB));
        legend.addView(Ui.tv(c, "  Mobile        ", 11, Ui.MUTED, false));
        legend.addView(dot(WIFI));
        legend.addView(Ui.tv(c, "  Wi-Fi", 11, Ui.MUTED, false));
        cc.addView(legend, Ui.lp(c, 8));
        root.addView(cc, Ui.lp(c, 12));

        // ---- data plan
        root.addView(Ui.section(c, "DATA PLAN"), Ui.lp(c, 26));
        LinearLayout pc = Ui.card(this);
        planText = Ui.tv(c, "", 13, Ui.WHITE, false);
        pc.addView(planText);
        planBar = new Ui.Bar(this);
        pc.addView(planBar, barLp(8, 12));
        float plan = sp.getFloat("planGb", 0f);
        lblPlan = Ui.tv(c, "", 13, Ui.WHITE, false);
        pc.addView(lblPlan, Ui.lp(c, 18));
        pc.addView(Ui.seek(c, 200, Math.round(plan * 2f), p -> {
            sp.edit().putFloat("planGb", p / 2f).apply();
            updatePlanLabels();
        }, this::planChanged), Ui.lp(c, 4));
        lblDay = Ui.tv(c, "", 13, Ui.WHITE, false);
        pc.addView(lblDay, Ui.lp(c, 14));
        pc.addView(Ui.seek(c, 27, sp.getInt("billDay", 1) - 1, p -> {
            sp.edit().putInt("billDay", p + 1).apply();
            updatePlanLabels();
        }, this::planChanged), Ui.lp(c, 4));
        pc.addView(Ui.tv(c, "Counts mobile data only. You get an alert at 80% and when the limit is reached.",
                11, Ui.MUTED, false), Ui.lp(c, 10));
        root.addView(pc, Ui.lp(c, 10));
        updatePlanLabels();

        // ---- per app
        root.addView(Ui.section(c, "PER APP"), Ui.lp(c, 26));
        root.addView(Ui.segmented(c, new String[]{"Today", "7 days", "Month"}, range, i -> {
            range = i;
            renderList();
        }), Ui.lp(c, 10));
        root.addView(Ui.segmented(c, new String[]{"All", "Mobile", "Wi-Fi"}, filter, i -> {
            filter = i;
            renderList();
        }), Ui.lp(c, 10));
        listHead = Ui.tv(c, "", 12, Ui.MUTED, false);
        root.addView(listHead, Ui.lp(c, 16));
        list = Ui.col(this);
        root.addView(list, Ui.lp(c, 8));
        return root;
    }

    private View dot(int color) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 9), Ui.dp(this, 9));
        p.gravity = Gravity.CENTER_VERTICAL;
        v.setLayoutParams(p);
        return v;
    }

    private LinearLayout.LayoutParams barLp(int hDp, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, hDp));
        p.topMargin = Ui.dp(this, topDp);
        return p;
    }

    private void updatePlanLabels() {
        float g = sp.getFloat("planGb", 0f);
        lblPlan.setText(g <= 0f ? "Monthly limit  \u00B7  off" : "Monthly limit  \u00B7  " + Fmt.gb(g) + " GB");
        lblDay.setText("Cycle starts on day " + sp.getInt("billDay", 1) + " of the month");
    }

    private void planChanged() {
        render();
        // let the background service re-check the plan right away
        if (Prefs.enabled(this)) {
            try {
                startService(new Intent(this, SpeedService.class).setAction(SpeedService.ACTION_REFRESH));
            } catch (Exception ignored) { }
        }
    }

    private void openUsageAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (Exception ignored) { }
        }
    }

    // ------------------------------------------------------------------ data

    private void reload() {
        if (loading) return;
        loading = true;
        final int day = sp.getInt("billDay", 1);
        new Thread(() -> {
            final UsageStore.Snapshot s = UsageStore.load(this, day);
            runOnUiThread(() -> {
                loading = false;
                if (isDestroyed()) return;
                snap = s;
                render();
            });
        }, "np-usage").start();
    }

    private CharSequence defaultCaption() {
        if (snap == null) return "";
        long peak = 0, sum = 0;
        for (int i = 0; i < UsageStore.DAYS; i++) {
            long t = snap.dayMob[i] + snap.dayWifi[i];
            sum += t;
            peak = Math.max(peak, t);
        }
        return "Avg " + Fmt.bytes(sum / UsageStore.DAYS) + " / day  \u00B7  Peak day " + Fmt.bytes(peak)
                + "\nTouch the chart to inspect a day";
    }

    private void pickDay(int i) {
        if (snap == null || i < 0 || i >= UsageStore.DAYS) {
            chartCap.setText(defaultCaption());
            return;
        }
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -(UsageStore.DAYS - 1 - i));
        String d = new SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(cal.getTime());
        long m = snap.dayMob[i], w = snap.dayWifi[i];
        chartCap.setText(Ui.lines(d + "  \u00B7  " + Fmt.bytes(m + w),
                TextUtils.concat(Ui.dotted(MOB, "Mobile " + Fmt.bytes(m) + "      "),
                        Ui.dotted(WIFI, "Wi-Fi " + Fmt.bytes(w)))));
    }

    private void render() {
        updatePlanLabels();
        if (snap == null) {
            bound = null;
            todayBig.setText("\u2014");
            todayBig.setTag(null);
            todaySub.setText("");
            monthBig.setText("\u2014");
            monthBig.setTag(null);
            monthSub.setText("");
            planText.setText("Grant usage access to see your data plan progress.");
            planBar.set(0f, Ui.ACCENT, Ui.ACCENT2, false);
            chart.set(new long[0], new long[0]);
            chartCap.setText("");
            renderList();
            return;
        }
        boolean fresh = bound != snap;
        bound = snap;
        if (fresh) {
            Ui.countBytes(todayBig, snap.todayMob + snap.todayWifi);
            todaySub.setText(Ui.lines(Ui.dotted(MOB, "Mobile " + Fmt.bytes(snap.todayMob)),
                    Ui.dotted(WIFI, "Wi-Fi " + Fmt.bytes(snap.todayWifi))));
            Ui.countBytes(monthBig, snap.monthMob + snap.monthWifi);
            monthSub.setText(Ui.lines(Ui.dotted(MOB, "Mobile " + Fmt.bytes(snap.monthMob)),
                    Ui.dotted(WIFI, "Wi-Fi " + Fmt.bytes(snap.monthWifi))));
            monthLbl.setText("SINCE " + new SimpleDateFormat("d MMM", Locale.getDefault())
                    .format(new Date(snap.cycleStart)).toUpperCase(Locale.getDefault()));
        }

        float g = sp.getFloat("planGb", 0f);
        if (g > 0f) {
            float frac = (float) (snap.monthMob / (g * 1e9));
            planText.setText(Fmt.bytes(snap.monthMob) + " of " + Fmt.gb(g) + " GB mobile data  \u00B7  "
                    + Math.round(frac * 100f) + "%");
            if (frac >= 1f) planBar.set(frac, Ui.BAD, Ui.PINK, true);
            else if (frac >= 0.8f) planBar.set(frac, Ui.WARN, 0xFFFF8A3D, true);
            else planBar.set(frac, Ui.ACCENT, Ui.ACCENT2, true);
        } else {
            planText.setText("No limit set. Move the slider below to get alerts.");
            planBar.set(0f, Ui.ACCENT, Ui.ACCENT2, true);
        }

        if (fresh) {
            chart.set(snap.dayMob, snap.dayWifi);
            chartCap.setText(defaultCaption());
            renderList();
        }
    }

    private void renderList() {
        list.removeAllViews();
        listHead.setText("");
        if (snap == null) return;
        SparseArray<long[]> src = range == 0 ? snap.today : range == 1 ? snap.week : snap.month;
        ArrayList<Row> rows = new ArrayList<>();
        long total = 0;
        for (int i = 0; i < src.size(); i++) {
            long[] v = src.valueAt(i);
            Row r = new Row();
            r.uid = src.keyAt(i);
            r.mob = v[0];
            r.wifi = v[1];
            r.v = filter == 0 ? v[0] + v[1] : filter == 1 ? v[0] : v[1];
            if (r.v <= 0) continue;
            total += r.v;
            rows.add(r);
        }
        Collections.sort(rows, (x, y) -> Long.compare(y.v, x.v));
        String rname = range == 0 ? "Today" : range == 1 ? "Last 7 days" : "This month";
        listHead.setText(rname + "  \u00B7  " + Fmt.bytes(total) + "  \u00B7  " + rows.size() + " apps");
        if (rows.isEmpty()) {
            list.addView(Ui.tv(this, "No usage recorded for this period.", 12, Ui.MUTED, false));
            return;
        }
        long max = rows.get(0).v;
        int n = Math.min(60, rows.size());
        for (int i = 0; i < n; i++) {
            View row = appRow(rows.get(i), max);
            list.addView(row, Ui.lp(this, i == 0 ? 0 : 10));
            if (i < 14) Ui.reveal(row, i * 38L);
        }
    }

    private View appRow(Row r, long max) {
        Context c = this;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.glass(c, 20));
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12));

        ImageView iv = new ImageView(this);
        Drawable d = snap.icons.get(r.uid);
        if (d == null) d = getPackageManager().getDefaultActivityIcon();
        iv.setImageDrawable(d);
        final int rad = Ui.dp(c, 11);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });
        iv.setClipToOutline(true);
        row.addView(iv, new LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 40)));

        LinearLayout mid = Ui.col(this);
        mid.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 10), 0);
        TextView name = Ui.tv(c, snap.names.get(r.uid, "UID " + r.uid), 14, Ui.WHITE, true);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        mid.addView(name);
        Ui.Bar bar = new Ui.Bar(this);
        mid.addView(bar, barLp(4, 7));
        bar.set(max > 0 ? (float) r.v / max : 0f, MOB, WIFI, true);
        mid.addView(Ui.tv(c, "Mobile " + Fmt.bytes(r.mob) + "   \u00B7   Wi-Fi " + Fmt.bytes(r.wifi),
                11, Ui.MUTED, false), Ui.lp(c, 7));
        row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        row.addView(Ui.tv(c, Fmt.bytes(r.v), 14, Ui.WHITE, true));
        return row;
    }

    // ------------------------------------------------------------------ chart

    /** Stacked daily bars (Wi-Fi bottom, mobile on top), grow-in animation, touch to inspect a day. */
    private static final class Chart extends View {
        interface Pick { void pick(int idx); }

        Pick cb;
        private long[] a = new long[0], b = new long[0];
        private float grow = 1f;
        private int sel = -1;
        private boolean moved;
        private int prevSel;
        private ValueAnimator anim;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rf = new RectF();
        private final float d;

        Chart(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            tp.setTextSize(9f * c.getResources().getDisplayMetrics().scaledDensity);
            tp.setColor(Ui.DIM);
        }

        void set(long[] mob, long[] wifi) {
            a = mob;
            b = wifi;
            sel = -1;
            if (anim != null) anim.cancel();
            if (mob.length == 0) {
                grow = 1f;
                invalidate();
                return;
            }
            grow = 0f;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(1000L);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator an) {
                    grow = (float) an.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }

        private float ease(float t) {
            t = Math.max(0f, Math.min(1f, t));
            float u = 1f - t;
            return 1f - u * u * u;
        }

        private void barPath(float l, float t, float r, float bt, float rad, boolean roundTop, boolean roundBottom) {
            path.reset();
            rf.set(l, t, r, bt);
            float rt = roundTop ? rad : 0f, rb = roundBottom ? rad : 0f;
            path.addRoundRect(rf, new float[]{rt, rt, rt, rt, rb, rb, rb, rb}, Path.Direction.CW);
        }

        @Override
        protected void onDraw(Canvas cv) {
            int n = a.length;
            float w = getWidth(), h = getHeight();
            float top = 16 * d, bottom = h - 4 * d;
            p.setColor(0x14FFFFFF);
            for (int k = 0; k < 3; k++) {
                float y = top + (bottom - top) * k / 2f;
                cv.drawRect(0, y, w, y + Math.max(1f, d * 0.8f), p);
            }
            if (n == 0) return;
            long max = 1;
            for (int i = 0; i < n; i++) max = Math.max(max, a[i] + b[i]);
            cv.drawText(Fmt.bytes(max), 0f, 10 * d, tp);
            float gap = 3 * d;
            float bw = (w - gap * (n - 1)) / n;
            float rad = Math.min(bw / 2f, 4 * d);
            for (int i = 0; i < n; i++) {
                float x = i * (bw + gap);
                long total = a[i] + b[i];
                float e = ease((grow - 0.5f * i / n) / 0.5f);
                int al = sel < 0 ? (i == n - 1 ? 255 : 205) : (i == sel ? 255 : 80);
                if (total == 0) {
                    p.setColor(Ui.alpha(0xFFFFFFFF, Math.min(al, 60)));
                    barPath(x, bottom - 2 * d, x + bw, bottom, d, true, true);
                    cv.drawPath(path, p);
                    continue;
                }
                float full = (bottom - top) * total / (float) max * e;
                float bh = Math.max(3 * d, full);
                float hw = bh * b[i] / (float) total;
                float hm = bh - hw;
                float yTop = bottom - bh;
                if (b[i] == 0) {
                    p.setColor(Ui.alpha(MOB, al));
                    barPath(x, yTop, x + bw, bottom, rad, true, true);
                    cv.drawPath(path, p);
                } else if (a[i] == 0) {
                    p.setColor(Ui.alpha(WIFI, al));
                    barPath(x, yTop, x + bw, bottom, rad, true, true);
                    cv.drawPath(path, p);
                } else {
                    p.setColor(Ui.alpha(WIFI, al));
                    barPath(x, bottom - hw, x + bw, bottom, rad, false, true);
                    cv.drawPath(path, p);
                    p.setColor(Ui.alpha(MOB, al));
                    barPath(x, yTop, x + bw, bottom - hw, rad, true, false);
                    cv.drawPath(path, p);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int n = a.length;
            if (n == 0) return super.onTouchEvent(e);
            int idx = (int) (e.getX() / (getWidth() / (float) n));
            idx = Math.max(0, Math.min(n - 1, idx));
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    moved = false;
                    prevSel = sel;
                    choose(idx);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (idx != sel) {
                        moved = true;
                        choose(idx);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    getParent().requestDisallowInterceptTouchEvent(false);
                    if (!moved && idx == prevSel) choose(-1);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                default:
                    return super.onTouchEvent(e);
            }
        }

        private void choose(int i) {
            sel = i;
            invalidate();
            if (cb != null) cb.pick(i);
        }
    }
}
