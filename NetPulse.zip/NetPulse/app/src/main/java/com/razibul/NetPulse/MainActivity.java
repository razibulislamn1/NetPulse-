package com.razibul.NetPulse;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    private static final int[] RAINBOW = {
            0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000};

    private SharedPreferences sp;
    private ConnectivityManager cm;
    private final Handler h = new Handler(Looper.getMainLooper());

    private Ui.Gauge gauge;
    private Ui.Spark spark;
    private TextView stDown, stUp, stPeak, liveText;
    private View liveDot;
    private ObjectAnimator pulse;
    private Perm pNotif, pBattery, pUsage, pAuto;
    private final TextView[] swatches = new TextView[11];
    private View hueBox;
    private ImageView iconPrev;
    private long lastRx, lastTx, lastT;
    private float peak;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = Prefs.sp(this);
            cm = getSystemService(ConnectivityManager.class);
            if (!sp.contains("enabled")) sp.edit().putBoolean("enabled", true).apply();

            FrameLayout frame = new FrameLayout(this);
            frame.addView(new Ui.Aurora(this), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ScrollView sv = new ScrollView(this);
            sv.setFillViewport(true);
            sv.setVerticalScrollBarEnabled(false);
            sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
            LinearLayout root = build();
            sv.addView(root);
            frame.addView(sv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            Ui.edgeToEdge(this, frame, root, 22, 44, 18);
            setContentView(frame);
            Ui.revealChildren(root);
            Keeper.ensure(this);
        } catch (Throwable t) {
            showCrash(android.util.Log.getStackTraceString(t));
        }
    }

    /** Fallback screen: shows the error text so it can be copied and sent. */
    private void showCrash(String text) {
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText("NetPulse error (please copy and send this):\n\n" + text);
        t.setTextIsSelectable(true);
        t.setTextColor(Color.WHITE);
        t.setBackgroundColor(Color.BLACK);
        t.setTextSize(11);
        t.setPadding(dp(16), dp(48), dp(16), dp(32));
        sv.addView(t);
        setContentView(sv);
    }

    /** Card with the last saved crash (if any): Copy / Clear. */
    private View crashCard() {
        final java.io.File f = new java.io.File(getFilesDir(), App.CRASH_FILE);
        if (!f.exists()) return null;
        String txt;
        try {
            byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
            txt = new String(b, "UTF-8");
        } catch (Exception e) {
            return null;
        }
        if (txt.length() > 3000) txt = txt.substring(0, 3000);
        final String full = txt;
        final LinearLayout c = Ui.card(this);
        c.addView(Ui.tv(this, "Last crash", 15, Ui.BAD, true));
        TextView body = Ui.tv(this, full, 10, Ui.MUTED, false);
        body.setTextIsSelectable(true);
        c.addView(body, Ui.lp(this, 8));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView copy = Ui.button(this, "Copy");
        TextView clear = Ui.button(this, "Clear");
        row.addView(copy, weight(0));
        row.addView(clear, weight(8));
        c.addView(row, Ui.lp(this, 12));
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cb = getSystemService(android.content.ClipboardManager.class);
            cb.setPrimaryClip(android.content.ClipData.newPlainText("NetPulse crash", full));
        });
        clear.setOnClickListener(v -> {
            f.delete();
            c.setVisibility(View.GONE);
        });
        return c;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pNotif == null || gauge == null) return;   // onCreate failed: error screen is showing
        refreshPerms();
        applyPrefs();
        lastT = 0;
        peak = 0f;
        h.post(previewTick);
        if (pulse != null) pulse.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(previewTick);
        if (pulse != null) pulse.cancel();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        refreshPerms();
        if (code == 7 && res.length > 0 && res[0] != PackageManager.PERMISSION_GRANTED) openNotifSettings();
        applyPrefs();
    }

    // ------------------------------------------------------------------ UI

    private LinearLayout build() {
        LinearLayout root = Ui.col(this);
        root.setPadding(dp(18), dp(22), dp(18), dp(44));

        // ---- header
        LinearLayout head = Ui.col(this);
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(Ui.glass(this, 20));
        pill.setPadding(dp(12), dp(7), dp(14), dp(7));
        liveDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Ui.GOOD);
        liveDot.setBackground(dotBg);
        pill.addView(liveDot, new LinearLayout.LayoutParams(dp(8), dp(8)));
        liveText = Ui.tv(this, "LIVE", 11, Ui.WHITE, true);
        liveText.setLetterSpacing(0.16f);
        LinearLayout.LayoutParams ltp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ltp.leftMargin = dp(8);
        pill.addView(liveText, ltp);
        head.addView(pill, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pulse = ObjectAnimator.ofFloat(liveDot, View.ALPHA, 1f, 0.25f);
        pulse.setDuration(900L);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);

        TextView title = Ui.tv(this, "NetPulse", 34, Ui.WHITE, true);
        title.setLetterSpacing(-0.02f);
        Ui.gradientText(title, Ui.WHITE, 0xFFC9BDFF, Ui.ACCENT2);
        head.addView(title, Ui.lp(this, 16));
        head.addView(Ui.tv(this, "Live network speed, right in your status bar", 13, Ui.MUTED, false), Ui.lp(this, 4));
        root.addView(head);
        View crash = crashCard();
        if (crash != null) root.addView(crash, Ui.lp(this, 14));

        // ---- hero: gauge + stats + live graph
        LinearLayout hero = Ui.card(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        gauge = new Ui.Gauge(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stDown = Ui.tv(this, "0 B/s", 15, Ui.WHITE, true);
        stUp = Ui.tv(this, "0 B/s", 15, Ui.VIOLET, true);
        stPeak = Ui.tv(this, "0 B/s", 15, Ui.WHITE, true);
        stats.addView(statTile("\u2193  DOWNLOAD", stDown, 0), weight(0));
        stats.addView(statTile("\u2191  UPLOAD", stUp, 0), weight(8));
        stats.addView(statTile("\u25B2  PEAK", stPeak, 0), weight(8));
        hero.addView(stats, Ui.lp(this, 6));

        spark = new Ui.Spark(this);
        hero.addView(spark, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84)));
        ((LinearLayout.LayoutParams) spark.getLayoutParams()).topMargin = dp(16);
        hero.addView(Ui.tv(this, "LAST 45 SECONDS", 10, Ui.DIM, true), Ui.lp(this, 8));
        ((TextView) hero.getChildAt(hero.getChildCount() - 1)).setLetterSpacing(0.2f);
        root.addView(hero, Ui.lp(this, 18));

        // ---- master switch
        LinearLayout row = Ui.card(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout txt = Ui.col(this);
        txt.addView(Ui.tv(this, "Speed meter", 17, Ui.WHITE, true));
        txt.addView(Ui.tv(this, "Keeps running after you close the app \u00B7 sleeps when there is no internet",
                12, Ui.MUTED, false), Ui.lp(this, 4));
        row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Ui.Toggle sw = new Ui.Toggle(this, Prefs.enabled(this), on -> {
            sp.edit().putBoolean("enabled", on).apply();
            if (on) {
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
                }
                Keeper.ensure(this);
            } else {
                Keeper.disarm(this);
                stopService(new Intent(this, SpeedService.class));
            }
        });
        LinearLayout.LayoutParams swp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        swp.leftMargin = dp(14);
        row.addView(sw, swp);
        root.addView(row, Ui.lp(this, 14));

        // ---- data usage entry
        LinearLayout urow = Ui.card(this);
        urow.setOrientation(LinearLayout.HORIZONTAL);
        urow.setGravity(Gravity.CENTER_VERTICAL);
        TextView ico = Ui.tv(this, "\u2197", 20, Ui.WHITE, true);
        ico.setGravity(Gravity.CENTER);
        ico.setBackground(Ui.gradPill(this, 16));
        LinearLayout.LayoutParams icp = new LinearLayout.LayoutParams(dp(46), dp(46));
        icp.rightMargin = dp(14);
        urow.addView(ico, icp);
        LinearLayout utxt = Ui.col(this);
        utxt.addView(Ui.tv(this, "Data usage", 17, Ui.WHITE, true));
        utxt.addView(Ui.tv(this, "Daily & monthly \u00B7 per app \u00B7 30-day chart \u00B7 plan alerts",
                12, Ui.MUTED, false), Ui.lp(this, 4));
        urow.addView(utxt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        urow.addView(Ui.tv(this, "\u203A", 26, Ui.MUTED, false));
        Ui.press(urow);
        urow.setOnClickListener(v -> openUsage());
        root.addView(urow, Ui.lp(this, 12));

        // ---- speed test entry
        LinearLayout strow = Ui.card(this);
        strow.setOrientation(LinearLayout.HORIZONTAL);
        strow.setGravity(Gravity.CENTER_VERTICAL);
        TextView sico = Ui.tv(this, "\u26A1", 20, Ui.WHITE, true);
        sico.setGravity(Gravity.CENTER);
        sico.setBackground(Ui.gradPill(this, 16));
        LinearLayout.LayoutParams sicp = new LinearLayout.LayoutParams(dp(46), dp(46));
        sicp.rightMargin = dp(14);
        strow.addView(sico, sicp);
        LinearLayout sttxt = Ui.col(this);
        sttxt.addView(Ui.tv(this, "Speed test", 17, Ui.WHITE, true));
        sttxt.addView(Ui.tv(this, "Ping \u00B7 download \u00B7 upload with a live speedometer",
                12, Ui.MUTED, false), Ui.lp(this, 4));
        strow.addView(sttxt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        strow.addView(Ui.tv(this, "\u203A", 26, Ui.MUTED, false));
        Ui.press(strow);
        strow.setOnClickListener(v -> {
            startActivity(new Intent(this, SpeedTestActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });
        root.addView(strow, Ui.lp(this, 12));

        // ---- live preview of the status icon
        root.addView(Ui.section(this, "STATUS ICON"), Ui.lp(this, 26));
        LinearLayout prev = Ui.card(this);
        prev.setOrientation(LinearLayout.HORIZONTAL);
        prev.setGravity(Gravity.CENTER_VERTICAL);
        iconPrev = new ImageView(this);
        iconPrev.setBackground(Ui.glass(this, 14));
        iconPrev.setPadding(dp(10), dp(10), dp(10), dp(10));
        prev.addView(iconPrev, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout ptxt = Ui.col(this);
        ptxt.addView(Ui.tv(this, "Live preview", 15, Ui.WHITE, true));
        ptxt.addView(Ui.tv(this, "This is how the icon looks in the top bar. It is a real notification icon, "
                + "so the system places it next to the other icons and it never overlaps them. "
                + "Android draws it in one system colour.", 11, Ui.MUTED, false), Ui.lp(this, 4));
        LinearLayout.LayoutParams ptp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ptp.leftMargin = dp(14);
        prev.addView(ptxt, ptp);
        root.addView(prev, Ui.lp(this, 10));

        // ---- style
        root.addView(Ui.section(this, "ICON STYLE"), Ui.lp(this, 22));
        root.addView(Ui.segmented(this, new String[]{"Dual  \u2193\u2191", "Big number"},
                sp.getInt("iconStyle", Prefs.STYLE_DUAL), i -> {
                    sp.edit().putInt("iconStyle", i).apply();
                    applyPrefs();
                }), Ui.lp(this, 10));
        root.addView(Ui.tv(this, "Dual = download and upload in two rows. Big number = one value with its unit below "
                + "(download when \"Both\" is selected).", 11, Ui.MUTED, false), Ui.lp(this, 8));

        // ---- speed type
        root.addView(Ui.section(this, "SPEED TYPE"), Ui.lp(this, 22));
        root.addView(Ui.segmented(this, new String[]{"Download", "Upload", "Both \u2193\u2191", "Total"},
                sp.getInt("show", Prefs.SHOW_BOTH), i -> {
                    sp.edit().putInt("show", i).apply();
                    applyPrefs();
                }), Ui.lp(this, 10));

        // ---- unit
        root.addView(Ui.section(this, "UNIT"), Ui.lp(this, 22));
        root.addView(Ui.segmented(this, new String[]{"Bytes (MB/s)", "Bits (Mbps)"},
                sp.getBoolean("bits", false) ? 1 : 0, i -> {
                    sp.edit().putBoolean("bits", i == 1).apply();
                    applyPrefs();
                }), Ui.lp(this, 10));

        // ---- text look
        root.addView(Ui.section(this, "TEXT"), Ui.lp(this, 26));
        LinearLayout look = Ui.card(this);
        look.addView(Ui.tv(this, "Font", 13, Ui.WHITE, false));
        look.addView(Ui.segmented(this, new String[]{"Condensed", "Regular", "Mono", "Heavy"},
                sp.getInt("font", 0), i -> {
                    sp.edit().putInt("font", i).apply();
                    applyPrefs();
                }), Ui.lp(this, 8));
        final TextView lblSize = Ui.tv(this, "Text size  \u00B7  " + sp.getInt("iconScale", 100) + " %", 13, Ui.WHITE, false);
        look.addView(lblSize, Ui.lp(this, 16));
        look.addView(seek(190, sp.getInt("iconScale", 100) - 60, p -> {
            sp.edit().putInt("iconScale", p + 60).apply();
            lblSize.setText("Text size  \u00B7  " + (p + 60) + " %");
        }), Ui.lp(this, 4));
        look.addView(toggleRow("Bold text", "Heavier strokes are easier to read in a small icon", "bold", true),
                Ui.lp(this, 14));
        look.addView(toggleRow("Show arrows", "Small \u2193 \u2191 marks in the Dual style", "arrows", true),
                Ui.lp(this, 14));
        look.addView(toggleRow("Upload on top", "Swap the rows in the Dual style", "upFirst", false),
                Ui.lp(this, 14));
        look.addView(Ui.divider(this), Ui.dividerLp(this, 16));
        // force colour: Android draws status-bar icons in ONE system colour, so coloured text is drawn by an overlay
        LinearLayout ovRow = new LinearLayout(this);
        ovRow.setOrientation(LinearLayout.HORIZONTAL);
        ovRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout ovTxt = Ui.col(this);
        ovTxt.addView(Ui.tv(this, "Force colour on status bar", 13, Ui.WHITE, false));
        ovTxt.addView(Ui.tv(this, "Android shows notification icons in one system colour. This draws the speed "
                + "text in your Accent colour over the status bar instead. Needs \"Display over other apps\".",
                11, Ui.MUTED, false), Ui.lp(this, 3));
        ovRow.addView(ovTxt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Ui.Toggle ovSw = new Ui.Toggle(this, sp.getBoolean("overlay", false), on -> {
            sp.edit().putBoolean("overlay", on).apply();
            if (on && !Overlay.allowed(this)) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) { }
            }
            applyPrefs();
        });
        LinearLayout.LayoutParams ovp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ovp.leftMargin = dp(14);
        ovRow.addView(ovSw, ovp);
        look.addView(ovRow, Ui.lp(this, 16));
        final TextView lblPos = Ui.tv(this, "Colour text position  \u00B7  " + sp.getInt("ovX", 40) + " % from left",
                13, Ui.WHITE, false);
        look.addView(lblPos, Ui.lp(this, 14));
        look.addView(seek(100, sp.getInt("ovX", 40), p -> {
            sp.edit().putInt("ovX", p).apply();
            lblPos.setText("Colour text position  \u00B7  " + p + " % from left");
        }), Ui.lp(this, 4));
        root.addView(look, Ui.lp(this, 10));

        // ---- behaviour
        root.addView(Ui.section(this, "BEHAVIOUR"), Ui.lp(this, 26));
        LinearLayout beh = Ui.card(this);
        beh.addView(toggleRow("Data usage in notification", "Show today / this month under the speed",
                "showUsage", true));
        beh.addView(Ui.tv(this, "Refresh rate", 13, Ui.WHITE, false), Ui.lp(this, 16));
        beh.addView(Ui.segmented(this, new String[]{"1 s", "2 s", "3 s"},
                Math.max(1, Math.min(3, sp.getInt("refresh", 1))) - 1, i -> {
                    sp.edit().putInt("refresh", i + 1).apply();
                    applyPrefs();
                }), Ui.lp(this, 8));
        root.addView(beh, Ui.lp(this, 10));

        // ---- accent colour theme
        root.addView(Ui.section(this, "ACCENT COLOR"), Ui.lp(this, 26));
        LinearLayout themeCard = Ui.card(this);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(6);
        for (int i = 0; i < swatches.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(16);
            if (i == Prefs.T_HEAT) t.setText("\uD83D\uDD25");
            if (i == Prefs.T_RAINBOW) t.setText("\uD83C\uDF08");
            if (i == Prefs.T_CUSTOM) t.setText("\uD83C\uDFA8");
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = dp(40);
            p.height = dp(40);
            p.setMargins(dp(4), dp(4), dp(4), dp(4));
            t.setLayoutParams(p);
            t.setOnClickListener(v -> {
                sp.edit().putInt("theme", idx).apply();
                paintSwatches();
                hueBox.setVisibility(idx == Prefs.T_CUSTOM ? View.VISIBLE : View.GONE);
                applyPrefs();
            });
            Ui.press(t);
            swatches[i] = t;
            grid.addView(t);
        }
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gridLp.gravity = Gravity.CENTER_HORIZONTAL;
        themeCard.addView(grid, gridLp);
        themeCard.addView(Ui.tv(this, "Used in the app and as the accent of the notification in the shade. "
                + "\uD83D\uDD25 Heat = follows speed \u00B7 \uD83C\uDF08 Rainbow = auto cycle \u00B7 \uD83C\uDFA8 Custom = pick any colour",
                11, Ui.MUTED, false), Ui.lp(this, 10));
        hueBox = hueBar();
        hueBox.setVisibility(sp.getInt("theme", 1) == Prefs.T_CUSTOM ? View.VISIBLE : View.GONE);
        themeCard.addView(hueBox, Ui.lp(this, 10));
        root.addView(themeCard, Ui.lp(this, 10));
        paintSwatches();

        // ---- permissions
        root.addView(Ui.section(this, "PERMISSIONS"), Ui.lp(this, 26));
        LinearLayout perms = Ui.card(this);
        pNotif = new Perm("Notifications", "Needed for the status bar icon", true, () -> {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            } else {
                openNotifSettings();
            }
        });
        pBattery = new Perm("Unrestricted battery", "Keeps it alive after you close the app", true, () -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        pUsage = new Perm("Usage access", "Needed for daily, monthly & per-app data", true, this::openUsageAccess);
        pAuto = new Perm("Background & auto-start", "Some phones need Autostart ON and Battery Unrestricted",
                false, () -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                });
        perms.addView(pNotif.root);
        perms.addView(Ui.divider(this), Ui.dividerLp(this, 14));
        perms.addView(pBattery.root, Ui.lp(this, 14));
        perms.addView(Ui.divider(this), Ui.dividerLp(this, 14));
        perms.addView(pUsage.root, Ui.lp(this, 14));
        perms.addView(Ui.divider(this), Ui.dividerLp(this, 14));
        perms.addView(pAuto.root, Ui.lp(this, 14));
        root.addView(perms, Ui.lp(this, 10));

        root.addView(Ui.tv(this, "Tip: if the icon does not show in the top bar, allow Notifications for NetPulse and "
                + "make sure your phone is not limiting status-bar notification icons.", 11, Ui.DIM, false), Ui.lp(this, 18));

        // ---- developer
        LinearLayout dev = Ui.card(this);
        dev.setGravity(Gravity.CENTER_HORIZONTAL);
        dev.addView(Ui.section(this, "DEVELOPER"));
        dev.addView(Ui.tv(this, "Razibul Islam", 19, Ui.WHITE, true), Ui.lp(this, 10));
        LinearLayout icons = new LinearLayout(this);
        icons.setOrientation(LinearLayout.HORIZONTAL);
        icons.setGravity(Gravity.CENTER);
        icons.addView(iconBtn(R.drawable.ic_github, "https://github.com/razibulislamn1"));
        icons.addView(iconBtn(R.drawable.ic_facebook, "https://facebook.com/razibul.n1"));
        dev.addView(icons, Ui.lp(this, 14));
        root.addView(dev, Ui.lp(this, 22));
        return root;
    }

    private LinearLayout.LayoutParams weight(int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = dp(leftDp);
        return p;
    }

    private View statTile(String label, TextView value, int unused) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.glass(this, 18));
        t.setPadding(dp(12), dp(10), dp(8), dp(11));
        TextView l = Ui.tv(this, label, 9, Ui.MUTED, true);
        l.setLetterSpacing(0.14f);
        t.addView(l);
        value.setSingleLine(true);
        t.addView(value, Ui.lp(this, 5));
        return t;
    }

    private View iconBtn(int res, final String url) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.ACCENT, Ui.ACCENT3});
        g.setShape(GradientDrawable.OVAL);
        iv.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(54), dp(54));
        p.setMargins(dp(10), 0, dp(10), 0);
        iv.setLayoutParams(p);
        Ui.press(iv);
        iv.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });
        return iv;
    }

    private View hueBar() {
        FrameLayout f = new FrameLayout(this);
        View strip = new View(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, RAINBOW);
        g.setCornerRadius(dp(6));
        strip.setBackground(g);
        FrameLayout.LayoutParams sp1 = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(10), Gravity.CENTER_VERTICAL);
        sp1.leftMargin = dp(14);
        sp1.rightMargin = dp(14);
        f.addView(strip, sp1);
        SeekBar s = Ui.seek(this, 360, sp.getInt("hue", 200), p -> {
            sp.edit().putInt("hue", p).apply();
            paintSwatches();
        }, this::applyPrefs);
        s.setProgressTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        s.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        f.addView(s, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return f;
    }

    private void paintSwatches() {
        int sel = sp.getInt("theme", 1);
        for (int i = 0; i < swatches.length; i++) {
            GradientDrawable g;
            if (i < Prefs.COLORS.length) {
                g = new GradientDrawable();
                g.setColor(Prefs.COLORS[i]);
            } else if (i == Prefs.T_HEAT) {
                g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{0xFF4DA3FF, 0xFF3DFF8A, 0xFFFFE03D, 0xFFFF4D4D});
            } else if (i == Prefs.T_RAINBOW) {
                g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, RAINBOW);
                g.setGradientType(GradientDrawable.SWEEP_GRADIENT);
            } else {
                g = new GradientDrawable();
                g.setColor(Color.HSVToColor(new float[]{sp.getInt("hue", 200), 0.85f, 1f}));
            }
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(dp(i == sel ? 3 : 1), i == sel ? Color.WHITE : 0x33FFFFFF);
            swatches[i].setBackground(g);
            float s = i == sel ? 1.14f : 1f;
            swatches[i].animate().setStartDelay(0L).scaleX(s).scaleY(s).setDuration(220L).start();
        }
    }

    private SeekBar seek(int max, int val, final IntConsumer onChange) {
        return Ui.seek(this, max, val, onChange, this::applyPrefs);
    }

    /** One permission line: title, description, live status and a Grant / Manage button. */
    private final class Perm {
        final LinearLayout root;
        final TextView sub, btn;
        final boolean hasStatus;

        Perm(String title, String desc, boolean hasStatus, final Runnable action) {
            this.hasStatus = hasStatus;
            root = new LinearLayout(MainActivity.this);
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout left = Ui.col(MainActivity.this);
            left.addView(Ui.tv(MainActivity.this, title, 14, Ui.WHITE, true));
            left.addView(Ui.tv(MainActivity.this, desc, 11, Ui.MUTED, false), Ui.lp(MainActivity.this, 3));
            sub = Ui.tv(MainActivity.this, "", 12, Ui.MUTED, true);
            left.addView(sub, Ui.lp(MainActivity.this, 4));
            if (!hasStatus) sub.setVisibility(View.GONE);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.rightMargin = dp(10);
            root.addView(left, lp);
            btn = Ui.tv(MainActivity.this, hasStatus ? "Grant" : "Open", 12, Ui.WHITE, true);
            btn.setGravity(Gravity.CENTER);
            btn.setPadding(dp(16), dp(9), dp(16), dp(9));
            btn.setBackground(Ui.gradPill(MainActivity.this, 14));
            Ui.press(btn);
            btn.setOnClickListener(v -> action.run());
            root.addView(btn);
        }

        void set(boolean ok) {
            if (!hasStatus) return;
            sub.setText(ok ? "\u2714 Allowed" : "\u2716 Not allowed");
            sub.setTextColor(ok ? Ui.GOOD : Ui.BAD);
            btn.setText(ok ? "Manage" : "Grant");
            btn.setTextColor(ok ? Ui.MUTED : Ui.WHITE);
            btn.setBackground(ok ? Ui.glass(MainActivity.this, 14) : Ui.gradPill(MainActivity.this, 14));
        }
    }

    // ------------------------------------------------------------------ logic

    private void openUsage() {
        startActivity(new Intent(this, UsageActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void applyPrefs() {
        if (Prefs.enabled(this)) {
            startService(new Intent(this, SpeedService.class).setAction(SpeedService.ACTION_REFRESH)
                    .putExtra("usage", false));
        }
    }

    private void openUsageAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (Exception ignored) { }
        }
    }

    private void openNotifSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(i);
    }

    private void refreshPerms() {
        pNotif.set(getSystemService(NotificationManager.class).areNotificationsEnabled());
        pBattery.set(getSystemService(PowerManager.class).isIgnoringBatteryOptimizations(getPackageName()));
        pUsage.set(UsageStore.hasAccess(this));
    }

    private View toggleRow(String title, String desc, final String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout t = Ui.col(this);
        t.addView(Ui.tv(this, title, 13, Ui.WHITE, false));
        t.addView(Ui.tv(this, desc, 11, Ui.MUTED, false), Ui.lp(this, 3));
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Ui.Toggle sw = new Ui.Toggle(this, sp.getBoolean(key, def), on -> {
            sp.edit().putBoolean(key, on).apply();
            applyPrefs();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(14);
        row.addView(sw, p);
        return row;
    }

    private String netName() {
        Network n = cm.getActiveNetwork();
        if (n == null) return null;
        NetworkCapabilities nc = cm.getNetworkCapabilities(n);
        if (nc == null) return "ONLINE";
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "WI-FI";
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "MOBILE DATA";
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "ETHERNET";
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN";
        return "ONLINE";
    }

    private final Runnable previewTick = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime();
            long rx = Math.max(0L, TrafficStats.getTotalRxBytes());
            long tx = Math.max(0L, TrafficStats.getTotalTxBytes());
            String net = netName();
            boolean online = net != null;
            if (lastT > 0) {
                long dt = Math.max(1L, now - lastT);
                float d = Math.max(0L, rx - lastRx) * 1000f / dt;
                float u = Math.max(0L, tx - lastTx) * 1000f / dt;
                if (!online) {
                    d = 0f;
                    u = 0f;
                }
                boolean bits = sp.getBoolean("bits", false);
                boolean upMain = sp.getInt("show", Prefs.SHOW_BOTH) == Prefs.SHOW_UP;
                float main = upMain ? u : d;
                int col = Prefs.color(sp, main);
                peak = Math.max(peak, Math.max(d, u));

                iconPrev.setImageBitmap(IconArt.draw(sp, d, u));
                gauge.setTarget(main, bits, col, online ? (upMain ? "UPLOAD" : "DOWNLOAD") : "OFFLINE");
                spark.push(d, u, col);
                String[] fd = Fmt.speed(d, bits), fu = Fmt.speed(u, bits), fp = Fmt.speed(peak, bits);
                stDown.setText(fd[0] + " " + fd[1]);
                stDown.setTextColor(col);
                stUp.setText(fu[0] + " " + fu[1]);
                stPeak.setText(fp[0] + " " + fp[1]);

                liveText.setText(online ? "LIVE  \u00B7  " + net : "OFFLINE");
                ((GradientDrawable) liveDot.getBackground()).setColor(online ? Ui.GOOD : Ui.BAD);
            }
            lastRx = rx;
            lastTx = tx;
            lastT = now;
            h.postDelayed(this, 1000L);
        }
    };

    private int dp(int v) {
        return Ui.dp(this, v);
    }
}
