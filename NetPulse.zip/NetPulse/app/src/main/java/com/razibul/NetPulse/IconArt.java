package com.razibul.NetPulse;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;

/**
 * Draws the status-bar icon. The system shows a notification small icon in one colour (it only uses the
 * alpha channel), so everything here is drawn in white on a transparent 96 x 96 bitmap.
 * The same drawing is used by the service (real icon) and by the in-app live preview.
 */
final class IconArt {
    private IconArt() {}

    static final int SIZE = 96;
    static final String[] FONTS = {"sans-serif-condensed", "sans-serif", "monospace", "sans-serif-black"};

    static Bitmap draw(SharedPreferences p, float d, float u) {
        boolean bits = p.getBoolean("bits", false);
        int show = p.getInt("show", Prefs.SHOW_BOTH);
        int style = p.getInt("iconStyle", Prefs.STYLE_DUAL);
        int font = Math.max(0, Math.min(FONTS.length - 1, p.getInt("font", 0)));
        boolean bold = p.getBoolean("bold", true);
        boolean arrows = p.getBoolean("arrows", true);
        boolean upFirst = p.getBoolean("upFirst", false);
        float scale = Math.max(60, Math.min(250, p.getInt("iconScale", 100))) / 100f;

        Bitmap bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.WHITE);
        tp.setTypeface(Typeface.create(FONTS[font], bold ? Typeface.BOLD : Typeface.NORMAL));

        if (show == Prefs.SHOW_BOTH && style == Prefs.STYLE_DUAL) {
            float vTop = upFirst ? u : d, vBot = upFirst ? d : u;
            boolean downTop = !upFirst;
            float avail = arrows ? SIZE - 14f : SIZE - 2f;
            tp.setTextAlign(Paint.Align.RIGHT);
            float x = SIZE - 1f;
            // ONE fixed size for every value (B / K / M): it never changes with the speed
            fit(tp, "888K", 46f * scale, 66f, avail);
            cv.drawText(Fmt.compact(vTop, bits), x, 44f, tp);
            cv.drawText(Fmt.compact(vBot, bits), x, 92f, tp);
            if (arrows) {
                arrow(cv, tp, 1f, 26f, downTop);
                arrow(cv, tp, 1f, 74f, !downTop);
            }
        } else {
            float v = show == Prefs.SHOW_UP ? u : show == Prefs.SHOW_TOTAL ? d + u : d;
            String[] f = Fmt.speed(v, bits);
            tp.setTextAlign(Paint.Align.CENTER);
            fit(tp, "8888", 58f * scale, 70f, SIZE - 4f);
            cv.drawText(f[0], SIZE / 2f, 56f, tp);
            fit(tp, "MB/s", 32f * scale, 38f, SIZE - 4f);
            cv.drawText(f[1], SIZE / 2f, 92f, tp);
        }
        return bmp;
    }

    /**
     * Size depends only on font + the user's size setting, never on the value. The height grows with the
     * setting up to what physically fits in the 96 px icon ({@code maxSize}); if the widest sample is wider
     * than the icon, the glyphs are squeezed horizontally (keeping the height) instead of shrinking.
     */
    private static void fit(Paint tp, String widest, float size, float maxSize, float maxW) {
        size = Math.min(size, maxSize);
        tp.setTextScaleX(1f);
        tp.setTextSize(size);
        float w = tp.measureText(widest);
        if (w > maxW && w > 0f) {
            float sx = maxW / w;
            if (sx >= 0.55f) {
                tp.setTextScaleX(sx);
            } else {
                tp.setTextScaleX(0.55f);
                tp.setTextSize(size * sx / 0.55f);
            }
        }
    }

    private static void arrow(Canvas cv, Paint p, float x, float cy, boolean down) {
        Path path = new Path();
        float w = 11f, h = 9f;
        if (down) {
            path.moveTo(x, cy - h / 2f);
            path.lineTo(x + w, cy - h / 2f);
            path.lineTo(x + w / 2f, cy + h / 2f);
        } else {
            path.moveTo(x, cy + h / 2f);
            path.lineTo(x + w, cy + h / 2f);
            path.lineTo(x + w / 2f, cy - h / 2f);
        }
        path.close();
        cv.drawPath(path, p);
    }
}
