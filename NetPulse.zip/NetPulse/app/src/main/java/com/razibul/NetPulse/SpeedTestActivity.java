package com.razibul.NetPulse;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Built-in speed test: ping + jitter, then download, then upload, with a live speedometer and graph.
 *
 * How the number is measured (same idea as Ookla / fast.com):
 *  - several parallel connections (4 / 8 / 16) so one slow stream cannot hold the result back
 *  - the first 2 seconds (TCP slow start) are shown live but NOT counted in the result
 *  - result = real payload bytes in the measuring window / real time of that window
 * It is the only feature that uses INTERNET, and it only runs when you press Start.
 * Test data comes from Cloudflare's public speed-test servers.
 */
public class SpeedTestActivity extends Activity {

    private static final String BASE = "https://speed.cloudflare.com/";
    private static final String UP = BASE + "__up";
    private static final long WARM_MS = 2000L;
    private static final int[] DUR = {6, 10, 15};
    private static final int[] CONN = {4, 8, 16};
    private static final int UP_CHUNK = 25000000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;
    private Ui.Gauge gauge;
    private Ui.Spark spark;
    private TextView btn, status, share, rating;
    private TextView tPing, tJitter, tPeak, tDown, tUp, tData;
    private LinearLayout histBox;
    private boolean bits = true;
    private boolean running;
    private volatile int session;
    private volatile Phase phase;
    private volatile int downBytesReq = 100000000;
    private volatile String colo;
    // download / upload servers: Cloudflare first, the others are used automatically if no data arrives
    private static final String[] DN_NAME = {"Cloudflare", "OVH", "Tele2", "Hetzner"};
    private static final String[] DN_URL = {null,
            "https://proof.ovh.net/files/1Gb.dat",
            "https://speedtest.tele2.net/1GB.zip",
            "https://speed.hetzner.de/1GB.bin"};
    private static final String[] UP_NAME = {"Cloudflare", "Tele2"};
    private static final String[] UP_URL = {UP, "https://speedtest.tele2.net/upload.php"};
    private volatile int dSrv, uSrv;
    private volatile String lastErr;
    private final AtomicLong totalBytes = new AtomicLong();
    private float peakAll;
    private String lastShare = "";

    /** One measuring phase: a shared byte counter + the connections to cut when it ends. */
    private static final class Phase {
        final AtomicLong bytes = new AtomicLong();
        volatile boolean stop;
        final List<HttpURLConnection> conns = new ArrayList<>();

        synchronized void add(HttpURLConnection c) {
            if (stop) c.disconnect(); else conns.add(c);
        }

        synchronized void end() {
            stop = true;
            for (HttpURLConnection c : conns) {
                try { c.disconnect(); } catch (Exception ignored) { }
            }
            conns.clear();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Prefs.sp(this);
        bits = sp.getInt("stUnit", 0) == 0;
        FrameLayout frame = new FrameLayout(this);
        frame.addView(new Ui.Aurora(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout root = build();
        sv.addView(root);
        frame.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Ui.edgeToEdge(this, frame, root, 18, 40, 18);
        setContentView(frame);
        refreshHistory();
    }

    @Override
    protected void onPause() {
        super.onPause();
        cancel();
    }

    private LinearLayout build() {
        LinearLayout root = Ui.col(this);
        TextView back = Ui.tv(this, "\u2039  Back", 15, Ui.MUTED, true);
        back.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 10));
        Ui.press(back);
        back.setOnClickListener(v -> finish());
        root.addView(back);

        TextView title = Ui.tv(this, "Speed test", 30, Ui.WHITE, true);
        Ui.gradientText(title, Ui.WHITE, 0xFFC9BDFF, Ui.ACCENT2);
        root.addView(title, Ui.lp(this, 8));
        root.addView(Ui.tv(this, "Real-time ping, download and upload. Several connections at once, "
                + "warm-up not counted.", 13, Ui.MUTED, false), Ui.lp(this, 4));

        // ---- hero
        LinearLayout hero = Ui.card(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        gauge = new Ui.Gauge(this);
        gauge.setSpeedScale(true);
        gauge.setTarget(0f, bits, Ui.ACCENT2, "READY");
        hero.addView(gauge, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        rating = Ui.tv(this, "", 18, Ui.WHITE, true);
        rating.setGravity(Gravity.CENTER);
        hero.addView(rating, Ui.lp(this, 2));
        status = Ui.tv(this, "Press Start", 13, Ui.MUTED, false);
        status.setGravity(Gravity.CENTER);
        hero.addView(status, Ui.lp(this, 4));

        spark = new Ui.Spark(this);
        LinearLayout.LayoutParams sk = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 70));
        sk.topMargin = Ui.dp(this, 14);
        hero.addView(spark, sk);

        tPing = val(Ui.WHITE);
        tJitter = val(Ui.WHITE);
        tPeak = val(Ui.WARN);
        tDown = val(Ui.ACCENT2);
        tUp = val(Ui.VIOLET);
        tData = val(Ui.WHITE);
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(tile("\u2193  DOWNLOAD", tDown), tileLp(0));
        r1.addView(tile("\u2191  UPLOAD", tUp), tileLp(8));
        hero.addView(r1, Ui.lp(this, 16));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(tile("\u25CF  PING", tPing), tileLp(0));
        r2.addView(tile("\u223F  JITTER", tJitter), tileLp(8));
        r2.addView(tile("\u25B2  PEAK", tPeak), tileLp(8));
        hero.addView(r2, Ui.lp(this, 8));
        LinearLayout r3 = new LinearLayout(this);
        r3.setOrientation(LinearLayout.HORIZONTAL);
        r3.addView(tile("DATA USED", tData), tileLp(0));
        hero.addView(r3, Ui.lp(this, 8));
        root.addView(hero, Ui.lp(this, 18));

        btn = Ui.button(this, "Start test");
        btn.setTextSize(16);
        root.addView(btn, Ui.lp(this, 16));
        btn.setOnClickListener(v -> {
            if (running) cancel(); else start();
        });
        share = Ui.button(this, "Share result");
        share.setVisibility(View.GONE);
        root.addView(share, Ui.lp(this, 10));
        share.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, lastShare);
                startActivity(Intent.createChooser(i, "Share result"));
            } catch (Exception ignored) { }
        });

        // ---- options
        root.addView(Ui.section(this, "OPTIONS"), Ui.lp(this, 24));
        LinearLayout opt = Ui.card(this);
        opt.addView(Ui.tv(this, "Test", 13, Ui.WHITE, false));
        opt.addView(Ui.segmented(this, new String[]{"Download + Upload", "Download", "Upload"},
                sp.getInt("stMode", 0), i -> sp.edit().putInt("stMode", i).apply()), Ui.lp(this, 8));
        opt.addView(Ui.tv(this, "Measuring time per direction", 13, Ui.WHITE, false), Ui.lp(this, 16));
        opt.addView(Ui.segmented(this, new String[]{"Quick 6 s", "Normal 10 s", "Long 15 s"},
                sp.getInt("stDur", 1), i -> sp.edit().putInt("stDur", i).apply()), Ui.lp(this, 8));
        opt.addView(Ui.tv(this, "Connections (more = better for fast links)", 13, Ui.WHITE, false), Ui.lp(this, 16));
        opt.addView(Ui.segmented(this, new String[]{"4", "8", "16"},
                sp.getInt("stConn", 1), i -> sp.edit().putInt("stConn", i).apply()), Ui.lp(this, 8));
        opt.addView(Ui.tv(this, "Unit", 13, Ui.WHITE, false), Ui.lp(this, 16));
        opt.addView(Ui.segmented(this, new String[]{"Mbps", "MB/s"},
                sp.getInt("stUnit", 0), i -> {
                    sp.edit().putInt("stUnit", i).apply();
                    bits = i == 0;
                }), Ui.lp(this, 8));
        root.addView(opt, Ui.lp(this, 10));

        // ---- history
        root.addView(Ui.section(this, "HISTORY"), Ui.lp(this, 24));
        histBox = Ui.card(this);
        root.addView(histBox, Ui.lp(this, 10));

        root.addView(Ui.tv(this, "Uses your internet (mobile data too: a full test can use roughly 50-500 MB on a "
                + "fast link). Test data comes from Cloudflare's public speed-test servers; nothing is stored there.",
                11, Ui.DIM, false), Ui.lp(this, 16));
        return root;
    }

    /** Plain-language rating of a speed (bytes per second): colour + word. */
    private void rate(float bps) {
        float m = bps * 8f / 1000000f;
        String w;
        int c;
        if (m < 1f) { w = "Very slow"; c = Ui.BAD; }
        else if (m < 5f) { w = "Slow"; c = 0xFFFF8A3D; }
        else if (m < 25f) { w = "Okay"; c = 0xFFFFE03D; }
        else if (m < 100f) { w = "Good"; c = Ui.GOOD; }
        else if (m < 500f) { w = "Fast"; c = Ui.ACCENT2; }
        else { w = "Very fast"; c = Ui.VIOLET; }
        rating.setText(m <= 0f ? "" : w);
        rating.setTextColor(c);
    }

    private TextView val(int color) {
        return Ui.tv(this, "\u2014", 15, color, true);
    }

    private View tile(String label, TextView value) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.glass(this, 18));
        t.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 11));
        TextView l = Ui.tv(this, label, 9, Ui.MUTED, true);
        l.setLetterSpacing(0.14f);
        t.addView(l);
        value.setSingleLine(true);
        t.addView(value, Ui.lp(this, 5));
        return t;
    }

    private LinearLayout.LayoutParams tileLp(int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = Ui.dp(this, leftDp);
        return p;
    }

    // ------------------------------------------------------------------ control

    private String netName() {
        try {
            ConnectivityManager cm = getSystemService(ConnectivityManager.class);
            Network n = cm.getActiveNetwork();
            if (n == null) return null;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return "Online";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Mobile data";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN";
            return "Online";
        } catch (Exception e) {
            return "Online";
        }
    }

    private void start() {
        final String net = netName();
        if (net == null) {
            status.setText("No internet connection");
            return;
        }
        running = true;
        peakAll = 0f;
        totalBytes.set(0L);
        colo = null;
        downBytesReq = 100000000;
        dSrv = 0;
        uSrv = 0;
        lastErr = null;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        btn.setText("Stop");
        share.setVisibility(View.GONE);
        for (TextView t : new TextView[]{tPing, tJitter, tPeak, tDown, tUp, tData}) t.setText("\u2014");
        final int mode = sp.getInt("stMode", 0);
        final int durMs = DUR[Math.max(0, Math.min(2, sp.getInt("stDur", 1)))] * 1000;
        final int conns = CONN[Math.max(0, Math.min(2, sp.getInt("stConn", 1)))];
        final int id = ++session;
        new Thread(() -> runTest(id, net, mode, durMs, conns), "np-speedtest").start();
    }

    private void cancel() {
        session++;
        Phase p = phase;
        if (p != null) p.end();
        if (running) {
            running = false;
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            btn.setText("Start test");
            status.setText("Stopped");
            gauge.setTarget(0f, bits, Ui.ACCENT2, "READY");
            rating.setText("");
        }
    }

    // ------------------------------------------------------------------ test (background thread)

    private void runTest(final int id, final String net, final int mode, final int durMs, final int conns) {
        try {
            ui(id, () -> {
                status.setText("Measuring ping\u2026");
                gauge.setTarget(0f, bits, Ui.PINK, "PING");
            });
            final long[] pj = ping();
            ui(id, () -> {
                tPing.setText(pj[0] > 0 ? pj[0] + " ms" : "\u2014");
                tJitter.setText(pj[0] > 0 ? pj[1] + " ms" : "\u2014");
            });

            float dl = 0f, ul = 0f;
            if (mode != 2) {
                dl = measure(id, true, durMs, conns);
                final float f = dl;
                ui(id, () -> {
                    String[] s = Fmt.speed(f, bits);
                    tDown.setText(s[0] + " " + s[1]);
                });
            }
            if (mode != 1) {
                ul = measure(id, false, durMs, conns);
                final float f = ul;
                ui(id, () -> {
                    String[] s = Fmt.speed(f, bits);
                    tUp.setText(s[0] + " " + s[1]);
                });
            }

            final float fdl = dl, ful = ul;
            final boolean ok = dl > 0f || ul > 0f;
            final long data = totalBytes.get();
            final float peak = peakAll;
            ui(id, () -> {
                running = false;
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                btn.setText("Test again");
                tData.setText(Fmt.bytes(data));
                String[] pk = Fmt.speed(peak, bits);
                tPeak.setText(pk[0] + " " + pk[1]);
                if (ok) {
                    status.setText("Done  \u00B7  " + net + "  \u00B7  " + DN_NAME[dSrv]
                            + (dSrv == 0 && colo != null ? " " + colo : "")
                            + (fdl <= 0f && mode != 2 ? "\nDownload failed: " + lastErr : "")
                            + (ful <= 0f && mode != 1 ? "\nUpload failed: " + lastErr : ""));
                    gauge.setTarget(fdl > 0f ? fdl : ful, bits, fdl > 0f ? Ui.ACCENT2 : Ui.VIOLET,
                            fdl > 0f ? "DOWNLOAD" : "UPLOAD");
                    rate(fdl > 0f ? fdl : ful);
                    String[] a = Fmt.speed(fdl, bits), b = Fmt.speed(ful, bits);
                    lastShare = "NetPulse speed test (" + net + ")\n\u2193 " + (mode == 2 ? "-" : a[0] + " " + a[1])
                            + "   \u2191 " + (mode == 1 ? "-" : b[0] + " " + b[1])
                            + (pj[0] > 0 ? "   Ping " + pj[0] + " ms" : "");
                    share.setVisibility(View.VISIBLE);
                    saveHistory(net, fdl, ful, pj[0]);
                    refreshHistory();
                } else {
                    status.setText("Could not reach any test server. Check your connection.\n" + (lastErr != null ? lastErr : ""));
                    gauge.setTarget(0f, bits, Ui.BAD, "OFFLINE");
                }
            });
        } catch (InterruptedException e) {
            // cancelled
        } catch (Exception e) {
            ui(id, () -> {
                running = false;
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                btn.setText("Start test");
                status.setText("Test failed");
            });
        }
    }

    /** Runs on the UI thread only if this test was not cancelled in the meantime. */
    private void ui(final int id, final Runnable r) {
        h.post(() -> {
            if (id == session) r.run();
        });
    }

    private HttpURLConnection open(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setUseCaches(false);
        c.setRequestProperty("Cache-Control", "no-cache");
        c.setRequestProperty("Accept-Encoding", "identity");   // no gzip: count the real bytes
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Origin", "https://speed.cloudflare.com");
        c.setRequestProperty("Referer", "https://speed.cloudflare.com/");
        c.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36 NetPulse");
        return c;
    }

    /** Returns {ping ms, jitter ms}. Ping = median of the round trips; jitter = mean change between them. */
    private long[] ping() throws InterruptedException {
        List<Long> rtt = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            HttpURLConnection c = null;
            try {
                long t0 = SystemClock.elapsedRealtime();
                c = open(BASE + "__down?bytes=0&r=" + System.nanoTime());
                c.getResponseCode();
                if (colo == null) colo = c.getHeaderField("cf-meta-colo");
                InputStream in = c.getInputStream();
                while (in.read() >= 0) { /* drain so the connection can be reused */ }
                long dt = SystemClock.elapsedRealtime() - t0;
                if (i > 0) rtt.add(dt);          // first one pays DNS + TLS, skip it
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
            Thread.sleep(40L);
        }
        if (rtt.isEmpty()) return new long[]{-1L, 0L};
        long jit = 0L;
        for (int i = 1; i < rtt.size(); i++) jit += Math.abs(rtt.get(i) - rtt.get(i - 1));
        jit = rtt.size() > 1 ? jit / (rtt.size() - 1) : 0L;
        List<Long> sorted = new ArrayList<>(rtt);
        java.util.Collections.sort(sorted);
        return new long[]{sorted.get(sorted.size() / 2), jit};
    }

    /** Runs one phase and returns the average speed in bytes per second (warm-up not counted). */
    private float measure(final int id, final boolean down, int durMs, int conns) throws InterruptedException {
        final Phase ph = new Phase();
        phase = ph;
        for (int i = 0; i < conns; i++) {
            Thread t = new Thread(() -> {
                if (down) downWorker(ph); else upWorker(ph);
            }, "np-st-" + i);
            t.setDaemon(true);
            t.start();
            Thread.sleep(30L);                    // gentle ramp-up instead of a burst of handshakes
        }
        final int color = down ? Ui.ACCENT2 : Ui.VIOLET;
        final String label = down ? "DOWNLOAD" : "UPLOAD";
        final String what = down ? "Testing download" : "Testing upload";
        final long total = WARM_MS + durMs;
        long t0 = SystemClock.elapsedRealtime();
        long prevT = t0, prevB = 0L, warmB = -1L, warmT = 0L, lastB = 0L, lastT = t0, swT = t0;
        float smooth = 0f;
        int n = 0;
        while (true) {
            Thread.sleep(100L);
            if (id != session) {
                ph.end();
                throw new InterruptedException();
            }
            long now = SystemClock.elapsedRealtime();
            long b = ph.bytes.get();
            float inst = (b - prevB) * 1000f / Math.max(1L, now - prevT);
            prevB = b;
            prevT = now;
            if (b == 0L && now - swT >= 3500L) {
                // nothing arrived from this server: switch to the next one and start this phase's clock again
                int cur = down ? dSrv : uSrv, max = (down ? DN_URL.length : UP_URL.length) - 1;
                if (cur < max) {
                    if (down) dSrv = cur + 1; else uSrv = cur + 1;
                    swT = now;
                    t0 = now;
                    prevT = now;
                    prevB = 0L;
                    n = 0;
                    smooth = 0f;
                    final String nm = down ? DN_NAME[dSrv] : UP_NAME[uSrv];
                    ui(id, () -> status.setText("No data, switching to " + nm + "\u2026"));
                    continue;
                }
            }
            smooth = n == 0 ? inst : smooth * 0.65f + inst * 0.35f;
            n++;
            final float shownSpeed = smooth;
            final boolean counted = now - t0 >= WARM_MS;
            if (counted) peakAll = Math.max(peakAll, smooth);
            final boolean pushGraph = n % 5 == 0;
            final long liveData = totalBytes.get() + b;
            final float livePeak = peakAll;
            final TextView liveTile = down ? tDown : tUp;
            final long left = Math.max(0L, (total - (now - t0) + 999L) / 1000L);
            ui(id, () -> {
                gauge.setTarget(shownSpeed, bits, color, label);
                rate(shownSpeed);
                // numbers count up live while the test runs (the final average replaces them at the end)
                String[] lv = Fmt.speed(shownSpeed, bits);
                liveTile.setText(lv[0] + " " + lv[1]);
                tData.setText(Fmt.bytes(liveData));
                if (livePeak > 0f) {
                    String[] pk = Fmt.speed(livePeak, bits);
                    tPeak.setText(pk[0] + " " + pk[1]);
                }
                if (pushGraph) spark.push(down ? shownSpeed : 0f, down ? 0f : shownSpeed, color);
                if (pushGraph) status.setText(what + "\u2026  " + left + " s");
            });
            if (warmB < 0L && counted) {
                warmB = b;
                warmT = now;
            }
            lastB = b;
            lastT = now;
            if (now - t0 >= total) break;
        }
        ph.end();
        totalBytes.addAndGet(lastB);
        if (warmB < 0L || lastT <= warmT) return 0f;
        return (lastB - warmB) * 1000f / (lastT - warmT);
    }

    private void downWorker(Phase ph) {
        byte[] buf = new byte[131072];
        while (!ph.stop) {
            HttpURLConnection c = null;
            try {
                int srv = dSrv;
                c = open(srv == 0 ? BASE + "__down?bytes=" + downBytesReq + "&r=" + System.nanoTime()
                        : DN_URL[srv]);
                ph.add(c);
                int code = c.getResponseCode();
                if (code != 200) {
                    if (srv == 0 && downBytesReq > 25000000) downBytesReq = 25000000;   // use smaller files
                    throw new java.io.IOException("HTTP " + code);
                }
                InputStream in = c.getInputStream();
                int n;
                while (!ph.stop && (n = in.read(buf)) >= 0) ph.bytes.addAndGet(n);
            } catch (Exception e) {
                if (ph.stop) break;
                lastErr = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                try { Thread.sleep(300L); } catch (InterruptedException ie) { break; }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void upWorker(Phase ph) {
        byte[] buf = new byte[65536];
        while (!ph.stop) {
            HttpURLConnection c = null;
            try {
                c = open(UP_URL[uSrv]);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(UP_CHUNK);
                c.setRequestProperty("Content-Type", "application/octet-stream");
                ph.add(c);
                OutputStream o = c.getOutputStream();
                int left = UP_CHUNK;
                while (left > 0 && !ph.stop) {
                    int n = Math.min(buf.length, left);
                    o.write(buf, 0, n);
                    ph.bytes.addAndGet(n);
                    left -= n;
                }
                if (!ph.stop) c.getResponseCode();
            } catch (Exception e) {
                if (ph.stop) break;
                lastErr = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                try { Thread.sleep(300L); } catch (InterruptedException ie) { break; }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    // ------------------------------------------------------------------ history

    private void saveHistory(String net, float dl, float ul, long ping) {
        String old = sp.getString("stHist", "");
        String line = System.currentTimeMillis() + "|" + net + "|" + dl + "|" + ul + "|" + ping;
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] p = all.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(8, p.length); i++) {
            if (i > 0) sb.append('\n');
            sb.append(p[i]);
        }
        sp.edit().putString("stHist", sb.toString()).apply();
    }

    private void refreshHistory() {
        histBox.removeAllViews();
        String raw = sp.getString("stHist", "");
        if (raw.isEmpty()) {
            histBox.addView(Ui.tv(this, "Your last results will appear here.", 12, Ui.MUTED, false));
            return;
        }
        SimpleDateFormat df = new SimpleDateFormat("d MMM  HH:mm", Locale.getDefault());
        boolean first = true;
        for (String line : raw.split("\n")) {
            String[] f = line.split("\\|");
            if (f.length < 5) continue;
            try {
                float dl = Float.parseFloat(f[2]), ul = Float.parseFloat(f[3]);
                long ping = Long.parseLong(f[4]);
                String[] a = Fmt.speed(dl, bits), b = Fmt.speed(ul, bits);
                boolean isFirst = first;
                if (!isFirst) histBox.addView(Ui.divider(this), Ui.dividerLp(this, 10));
                first = false;
                histBox.addView(Ui.tv(this, df.format(new Date(Long.parseLong(f[0]))) + "  \u00B7  " + f[1],
                        11, Ui.MUTED, false), Ui.lp(this, isFirst ? 0 : 10));
                histBox.addView(Ui.tv(this, "\u2193 " + (dl > 0f ? a[0] + " " + a[1] : "-")
                        + "     \u2191 " + (ul > 0f ? b[0] + " " + b[1] : "-")
                        + (ping > 0 ? "     " + ping + " ms" : ""), 14, Ui.WHITE, true), Ui.lp(this, 3));
            } catch (Exception ignored) { }
        }
    }
}
