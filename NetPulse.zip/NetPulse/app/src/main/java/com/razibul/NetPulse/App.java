package com.razibul.NetPulse;

import android.app.Application;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;

/** Saves the last crash to a private file so the app can show it on the next start (no internet needed). */
public class App extends Application {
    static final String CRASH_FILE = "crash.txt";

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                String s = "NetPulse 4.2 | Android " + Build.VERSION.SDK_INT + " | " + Build.MANUFACTURER + " "
                        + Build.MODEL + " | thread " + t.getName() + "\n\n" + Log.getStackTraceString(e);
                try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), CRASH_FILE))) {
                    o.write(s.getBytes("UTF-8"));
                }
            } catch (Throwable ignored) { }
            if (old != null) old.uncaughtException(t, e);
        });
    }
}
